<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once '../config/database.php';
require '../vendor/autoload.php'; // PHPMailer autoload

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $contact = trim($_POST['contact']);

    try {
        $pdo = getDBConnection();

        // Check if user exists
        $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ? OR email = ?");
        $stmt->execute([$contact, $contact]);
        $admin = $stmt->fetch();

        if ($admin) {
            $otp = rand(100000, 999999);
            $_SESSION['reset_otp'] = $otp;
            $_SESSION['reset_email'] = $admin['email'];
            $_SESSION['reset_id'] = $admin['id'];
            $_SESSION['otp_expires'] = time() + 600; // 10 minutes validity

            // ✅ Send email using PHPMailer
            if (filter_var($contact, FILTER_VALIDATE_EMAIL)) {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = 'mail.iastm.in';
                $mail->SMTPAuth = true;
                $mail->Username = 'office@iastm.in';
                $mail->Password = '@Act2024';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                $mail->Port = 465;

                $mail->setFrom('office@iastm.in', 'IASTMYAW Support');
                $mail->addAddress($admin['email']);
                $mail->isHTML(true);
                $mail->Subject = 'Your OTP for Admin Password Reset';
                $mail->Body = "Your OTP is: <strong>$otp</strong><br>This OTP is valid for 10 minutes.";

                $mail->send();

                echo "<script>alert('✅ OTP sent successfully!'); window.location.href='verify_otp.php';</script>";
                exit();
            }
        } else {
            echo "<script>alert('❌ Admin not found!'); window.location.href='forgot_password.html';</script>";
        }
    } catch (Exception $e) {
        echo "Email error: " . $e->getMessage();
    }
}
?>
