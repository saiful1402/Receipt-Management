<?php
ob_start(); // Start output buffering
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../config/database.php';
// require_once __DIR__ . '/../config/database.php';

// var_dump($conn);
// if (!($conn instanceof mysqli)) {
//     die("ERROR: Database connection is not a MySQLi instance.");
// }
// var_dump($conn);
// exit;

// if (!isset($conn)) {
//     die("Database connection not loaded from config/database.php");
// }

// global $conn; // ensure $conn is available
// if (!isset($conn) || $conn->connect_error) {
//     die("DB connection issue: " . $conn->connect_error);
// }


// if (!isset($conn)) {
//     die("Database connection not initialized");
// } else {
//     echo "Connected to DB: " . DB_NAME . "<br>";
// }

// if (!$conn) {
//     die("DB connection not created");
// }

// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// Check if already logged in
if (!isset($_GET['force']) && isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: ../admin/dashboard.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($username) && !empty($password)) {
        // try {
        //     $pdo = getDBConnection();
        //     $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ?");
        //     $stmt->execute([$username]);
        //     $admin = $stmt->fetch();
        // $stmt = $conn->prepare("SELECT * FROM admin_users WHERE username = ?");

        // ✅ Correct way: Prepare the query first
        $stmt = $conn->prepare("SELECT id, username, password, role, full_name FROM admin_users WHERE username = ?");
        if (!$stmt) {
            die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
        }

        // bind parameter
        $stmt->bind_param("s", $username);
        $stmt->execute();
        // $result = $stmt->get_result();
        // $admin = $result->fetch_assoc();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $db_username, $db_password, $role, $full_name);
            $stmt->fetch();

            // if ($admin && password_verify($password, $admin['password'])) {
            if (password_verify($password, $db_password)) {
                // Check if using default password
                $defaultPasswordHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'; // "password"

                // if ($admin['password'] === $defaultPasswordHash) {
                if ($db_password === $defaultPasswordHash) {
                    $_SESSION['force_password_change'] = true;
                }

                // Set session
                $_SESSION['admin_logged_in'] = true;
                // $_SESSION['admin_id'] = $admin['id'];
                // $_SESSION['admin_username'] = $admin['username'];
                // $_SESSION['admin_role'] = $admin['role'];
                // $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['admin_id'] = $id;
                $_SESSION['admin_username'] = $db_username;
                $_SESSION['admin_role'] = $role;
                $_SESSION['admin_name'] = $full_name;

                // Redirect accordingly
                if (!empty($_SESSION['force_password_change'])) {
                    header('Location: ../admin/change_password.php');
                } else {
                    header('Location: ../admin/dashboard.php');
                }
                exit();
            } else {
                $error = 'Invalid username or password';
            }
        // } catch (PDOException $e) {
        //     $error = 'Login error: ' . $e->getMessage();
        // }
        } else {
            $error = 'Invalid username or password';
        }

        $stmt->close();
    } else {
        $error = 'Please enter both username and password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Billing Software</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1>Billing Software</h1>
                <h2>Admin Login</h2>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>

            <div class="form-footer" style="margin-top: 10px; text-align: center;">
                <a href="forgot_password.php" style="color: #007bff;">Forgot Password?</a>
            </div>
        </div>
    </div>
</body>
</html>

<?php
ob_end_flush(); // Flush output buffer
?>
