<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include "../config/database.php"; // provides $conn and generateMemberId()
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // collect & sanitize
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $address    = trim($_POST['address'] ?? '');
    $country    = trim($_POST['country'] ?? '');
    $city       = trim($_POST['city'] ?? '');
    $membership_type = $_POST['membership_type'] ?? '';
    $amount     = $_POST['amount'] ?? 0;
    $status     = 'pending'; // you can set 'active' if you want immediate activation

    // check if email already exists
    $check = $conn->prepare("SELECT id FROM members WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $message = "A member with this email already exists!";
    } else {
        try {
            $member_id = generateMemberId();
            $stmt = $conn->prepare("
                INSERT INTO members (member_id, first_name, last_name, email, phone, address, country, city, membership_type, amount, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                "sssssssssis",
                $member_id,
                $first_name,
                $last_name,
                $email,
                $phone,
                $address,
                $country,
                $city,
                $membership_type,
                $amount,
                $status
            );

            if ($stmt->execute()) {
                $message = "Registration successful! Your application is pending approval.";
            } else {
                $message = "Registration failed: " . $stmt->error;
            }
//             if ($stmt->execute()) {
//     echo "✅ Inserted! Last Insert ID: " . $stmt->insert_id . "<br>";
//     echo "Currently connected DB: " . $conn->query("SELECT DATABASE()")->fetch_row()[0] . "<br>";
//     $message = "Registration successful! Your application is pending approval.";
// } else {
//     echo "❌ Error: " . $stmt->error . "<br>";
//     echo "Currently connected DB: " . $conn->query("SELECT DATABASE()")->fetch_row()[0] . "<br>";
//     $message = "Registration failed. Please try again.";
// }
        } catch (Exception $e) {
            $message = "Error: " . $e->getMessage();
        }
    }
    $check->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Member Registration - Applied Computer Technology</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            padding: 0;
            font-family: 'Roboto', Arial, sans-serif;
            background:rgb(247, 237, 246);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-container {
            background: white;
            padding: 40px 30px;
            border-radius: 10px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.07);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .register-container h1 {
            font-size: 32px;
            color: #6c757d;
            font-weight: 300;
            margin-bottom: 10px;
        }
        .register-container h1 span {
            color: #007bff;
            font-weight: 600;
        }
        .register-container p {
            color: #6c757d;
            font-size: 16px;
            margin-bottom: 0;
        }
        .register-form {
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 18px;
            position: relative;
            display: flex;
            align-items: center;
        }
        .form-control {
            width: 100%;
            padding: 12px 40px 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            background: #fff;
            box-sizing: border-box;
            margin: 0;
        }
        .form-control:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.08);
        }
        .input-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            font-size: 18px;
            pointer-events: none;
        }
        .form-select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            background: #fff;
            box-sizing: border-box;
            margin: 0;
        }
        .checkbox-container {
            display: flex;
            align-items: center;
            margin-bottom: 18px;
        }
        .checkbox-container input[type="checkbox"] {
            margin-right: 10px;
            transform: scale(1.2);
        }
        .checkbox-container label {
            color: #6c757d;
            font-size: 14px;
            user-select: none;
            cursor: pointer;
        }
        .checkbox-container a {
            color: #007bff;
            text-decoration: none;
        }
        .checkbox-container a:hover {
            text-decoration: underline;
        }
        .btn-register {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-bottom: 18px;
        }
        .btn-register:hover {
            background: #0056b3;
        }
        .divider {
            text-align: center;
            margin: 18px 0;
            color: #6c757d;
            font-size: 14px;
            position: relative;
        }
        .divider::before,
        .divider::after {
            content: '';
            position: absolute;
            top: 50%;
            width: 45%;
            height: 1px;
            background: #ddd;
        }
        .divider::before { left: 0; }
        .divider::after { right: 0; }
        .btn-social {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        .btn-facebook { background: #3b5998; color: white; }
        .btn-facebook:hover { background: #2d4373; }
        .btn-google { background: #dc3545; color: white; }
        .btn-google:hover { background: #c82333; }
        .login-link {
            text-align: center;
            margin-top: 10px;
        }
        .login-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 10px 15px;
            border-radius: 5px;
            border: 1px solid #f5c6cb;
            margin-bottom: 18px;
            font-size: 14px;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 10px 15px;
            border-radius: 5px;
            border: 1px solid #c3e6cb;
            margin-bottom: 18px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h1>IASTM Membership</h1>
        <p>As a professional organization, harvesting knowledge, continuous collaboration with high quality institutes, improvement of processes for furnishing research activities etc. would be the main objective of this organization.</p>
        <p>website: <a href="#">www.iastm.in</a> , Email: <strong>info@iastm.in</strong></p>
        <form class="register-form" method="POST" action="">
            <?php if ($message): ?>
                <div class="<?= strpos($message, 'success') !== false ? 'success-message' : 'error-message' ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>
            <div class="form-group">
                <input type="text" name="first_name" class="form-control" placeholder="First Name" required>
                <i class="fas fa-user input-icon"></i>
            </div>
            <div class="form-group">
                <input type="text" name="last_name" class="form-control" placeholder="Last Name" required>
                <i class="fas fa-user input-icon"></i>
            </div>
            <div class="form-group">
                <input type="email" name="email" class="form-control" placeholder="Email" required>
                <i class="fas fa-envelope input-icon"></i>
            </div>
            <div class="form-group">
                <input type="text" name="phone" class="form-control" placeholder="Phone Number" required>
                <i class="fas fa-phone input-icon"></i>
            </div>
            <div class="form-group">
                <input type="text" name="username" class="form-control" placeholder="Username" required>
                <i class="fas fa-user-circle input-icon"></i>
            </div>
            <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
                <i class="fas fa-lock input-icon"></i>
            </div>
            <div class="form-group">
                <input type="password" name="retype_password" class="form-control" placeholder="Retype password" required>
                <i class="fas fa-lock input-icon"></i>
            </div>
            <div class="form-group">
                <textarea name="address" class="form-control" placeholder="Address" required></textarea>
            </div>
            <div class="form-group">
<input list="countryList" class="form-control" name="country" placeholder="Country" required>
<datalist id="countryList">
  <option value="Afghanistan">
  <option value="Albania">
  <option value="Algeria">
  <option value="Andorra">
  <option value="Angola">
  <option value="Argentina">
  <option value="Armenia">
  <option value="Australia">
  <option value="Austria">
  <option value="Azerbaijan">
  <option value="Bahamas">
  <option value="Bahrain">
  <option value="Bangladesh">
  <option value="Barbados">
  <option value="Belarus">
  <option value="Belgium">
  <option value="Belize">
  <option value="Benin">
  <option value="Bhutan">
  <option value="Bolivia">
  <option value="Bosnia and Herzegovina">
  <option value="Botswana">
  <option value="Brazil">
  <option value="Brunei">
  <option value="Bulgaria">
  <option value="Burkina Faso">
  <option value="Burundi">
  <option value="Cambodia">
  <option value="Cameroon">
  <option value="Canada">
  <option value="Cape Verde">
  <option value="Central African Republic">
  <option value="Chad">
  <option value="Chile">
  <option value="China">
  <option value="Colombia">
  <option value="Comoros">
  <option value="Costa Rica">
  <option value="Croatia">
  <option value="Cuba">
  <option value="Cyprus">
  <option value="Czech Republic">
  <option value="Denmark">
  <option value="Djibouti">
  <option value="Dominica">
  <option value="Dominican Republic">
  <option value="Ecuador">
  <option value="Egypt">
  <option value="El Salvador">
  <option value="Equatorial Guinea">
  <option value="Eritrea">
  <option value="Estonia">
  <option value="Eswatini">
  <option value="Ethiopia">
  <option value="Fiji">
  <option value="Finland">
  <option value="France">
  <option value="Gabon">
  <option value="Gambia">
  <option value="Georgia">
  <option value="Germany">
  <option value="Ghana">
  <option value="Greece">
  <option value="Grenada">
  <option value="Guatemala">
  <option value="Guinea">
  <option value="Guyana">
  <option value="Haiti">
  <option value="Honduras">
  <option value="Hungary">
  <option value="Iceland">
  <option value="India">
  <option value="Indonesia">
  <option value="Iran">
  <option value="Iraq">
  <option value="Ireland">
  <option value="Israel">
  <option value="Italy">
  <option value="Jamaica">
  <option value="Japan">
  <option value="Jordan">
  <option value="Kazakhstan">
  <option value="Kenya">
  <option value="Kiribati">
  <option value="Kuwait">
  <option value="Kyrgyzstan">
  <option value="Laos">
  <option value="Latvia">
  <option value="Lebanon">
  <option value="Lesotho">
  <option value="Liberia">
  <option value="Libya">
  <option value="Liechtenstein">
  <option value="Lithuania">
  <option value="Luxembourg">
  <option value="Madagascar">
  <option value="Malawi">
  <option value="Malaysia">
  <option value="Maldives">
  <option value="Mali">
  <option value="Malta">
  <option value="Marshall Islands">
  <option value="Mauritania">
  <option value="Mauritius">
  <option value="Mexico">
  <option value="Micronesia">
  <option value="Moldova">
  <option value="Monaco">
  <option value="Mongolia">
  <option value="Montenegro">
  <option value="Morocco">
  <option value="Mozambique">
  <option value="Myanmar">
  <option value="Namibia">
  <option value="Nauru">
  <option value="Nepal">
  <option value="Netherlands">
  <option value="New Zealand">
  <option value="Nicaragua">
  <option value="Niger">
  <option value="Nigeria">
  <option value="North Korea">
  <option value="North Macedonia">
  <option value="Norway">
  <option value="Oman">
  <option value="Pakistan">
  <option value="Palau">
  <option value="Palestine">
  <option value="Panama">
  <option value="Papua New Guinea">
  <option value="Paraguay">
  <option value="Peru">
  <option value="Philippines">
  <option value="Poland">
  <option value="Portugal">
  <option value="Qatar">
  <option value="Romania">
  <option value="Russia">
  <option value="Rwanda">
  <option value="Saint Kitts and Nevis">
  <option value="Saint Lucia">
  <option value="Saint Vincent and the Grenadines">
  <option value="Samoa">
  <option value="San Marino">
  <option value="Sao Tome and Principe">
  <option value="Saudi Arabia">
  <option value="Senegal">
  <option value="Serbia">
  <option value="Seychelles">
  <option value="Sierra Leone">
  <option value="Singapore">
  <option value="Slovakia">
  <option value="Slovenia">
  <option value="Solomon Islands">
  <option value="Somalia">
  <option value="South Africa">
  <option value="South Korea">
  <option value="South Sudan">
  <option value="Spain">
  <option value="Sri Lanka">
  <option value="Sudan">
  <option value="Suriname">
  <option value="Sweden">
  <option value="Switzerland">
  <option value="Syria">
  <option value="Taiwan">
  <option value="Tajikistan">
  <option value="Tanzania">
  <option value="Thailand">
  <option value="Togo">
  <option value="Tonga">
  <option value="Trinidad and Tobago">
  <option value="Tunisia">
  <option value="Turkey">
  <option value="Turkmenistan">
  <option value="Tuvalu">
  <option value="Uganda">
  <option value="Ukraine">
  <option value="United Arab Emirates">
  <option value="United Kingdom">
  <option value="United States">
  <option value="Uruguay">
  <option value="Uzbekistan">
  <option value="Vanuatu">
  <option value="Vatican City">
  <option value="Venezuela">
  <option value="Vietnam">
  <option value="Yemen">
  <option value="Zambia">
  <option value="Zimbabwe">
</datalist>
            </div>
            <div class="form-group">
                <input type="text" name="city" class="form-control" placeholder="City" required>
            </div>
            <div class="form-group">
                <select name="membership_type" class="form-select" required>
                    <option value="">-- Select Membership Type --</option>
                    <option value="life member">Life Member</option>
                    <option value="executive member">Executive Member</option>
                    <option value="associate member">Associate Member</option>
                    <option value="student member">Student Member</option>
                </select>
            </div>
            <div class="form-group">
                <input type="number" name="amount" class="form-control" placeholder="amount" required>
            </div>
            <div class="checkbox-container">
                <input type="checkbox" id="terms" required>
                <label for="terms">I agree to the <a href="#">terms</a></label>
            </div>
            <button type="submit" class="btn-register">Register</button>
            <div class="divider">- OR -</div>
            <!-- <button type="button" class="btn-social btn-facebook"><i class="fab fa-facebook-f"></i> Sign up using Facebook</button>
            <button type="button" class="btn-social btn-google"><i class="fab fa-google-plus-g"></i> Sign up using Google+</button> -->
            <div class="login-link">
                <a href="../auth/login.php?force=true">I already have a membership</a>
            </div>
        </form>
    </div>
</body>
</html>