<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['otp_verified']) || $_SESSION['otp_verified'] !== true) {
    header("Location: forgot_password.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if ($newPassword === $confirm) {
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed, $_SESSION['reset_id']]);

        // Clear reset session
        session_unset();
        session_destroy();

        echo "<script>alert('✅ Password reset successful!'); window.location.href='login.php';</script>";
        exit();
    } else {
        echo "<script>alert('❌ Passwords do not match!');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>
<body>
    <h2>Reset Password</h2>
    <form method="POST">
        <label>New Password:</label>
        <input type="password" name="new_password" required><br>
        <label>Confirm Password:</label>
        <input type="password" name="confirm_password" required><br>
        <button type="submit">Reset</button>
    </form>
</body>
</html>
