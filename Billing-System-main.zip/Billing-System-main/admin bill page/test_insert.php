<?php
require_once 'config/database.php'; // adjust path if needed

try {
    $pdo = getDBConnection();

    // Sample insert
    $stmt = $pdo->prepare("
        INSERT INTO members (member_id, first_name, last_name, email, phone, address, country, city, membership_type, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $result = $stmt->execute([
        'MEMTEST123',       // member_id
        'TEST',             // first_name
        'User',             // last_name
        'test@example.com', // email
        '1234567890',       // phone
        '123 Test Street',  // address
        'India',            // country
        'Kolkata',          // city
        'life member',      // membership_type
        'active'            // status
    ]);

    if ($result) {
        echo "<h2 style='color:green'>✅ Insert successful!</h2>";
    } else {
        echo "<h2 style='color:red'>❌ Insert failed!</h2>";
    }

} catch (PDOException $e) {
    echo "<h2 style='color:red'>❌ Database error:</h2> " . $e->getMessage();
}
