<?php
$inputPassword = 'admin123';
$storedHash = '$2y$10$eW5HtV3CB1GO9tn0AE1qJ.lHVZkJXRx0p5GiJ4rw4Eh2H2s5OYsNe';

if (password_verify($inputPassword, $storedHash)) {
    echo "✅ Password matches.";
} else {
    echo "❌ Password does NOT match.";
}
