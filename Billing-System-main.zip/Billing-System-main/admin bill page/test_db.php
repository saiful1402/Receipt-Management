<?php
require_once 'config/database.php';
 // adjust path if needed

try {
    $pdo = getDBConnection();
    echo "<h2 style='color:green'>✅ Database connection successful!</h2>";
} catch (PDOException $e) {
    echo "<h2 style='color:red'>❌ Database connection failed:</h2> " . $e->getMessage();
}

