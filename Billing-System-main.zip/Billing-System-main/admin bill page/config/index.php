<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACT Billing - Welcome</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', Arial, sans-serif;
            background: #f4f6f9;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-container {
            width: 60px;
            height: 60px;
            background-color: white;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .logo-container img {
            max-width: 50px;
            max-height: 50px;
            object-fit: contain;
        }

        .company-name {
            font-size: 2rem;
            font-weight: 600;
            letter-spacing: 1px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 2rem;
            text-align: center;
        }

        .welcome-section {
            background: white;
            padding: 3rem 2.5rem;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
            max-width: 700px;
            width: 100%;
        }

        .welcome-title {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 1rem;
            font-weight: 400;
        }

        .welcome-title .highlight {
            color: #007bff;
            font-weight: 600;
        }

        .welcome-subtitle {
            font-size: 1.1rem;
            color: #6c757d;
            margin-bottom: 3rem;
            line-height: 1.6;
        }

        .action-buttons {
            display: flex;
            gap: 2rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .action-card {
            background: white;
            padding: 2.5rem 2rem;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
            min-width: 250px;
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }

        .action-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .action-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
            border-color: #007bff;
        }

        .admin-card::before {
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .member-card::before {
            background: linear-gradient(90deg, #f093fb, #f5576c);
        }

        .card-icon {
            font-size: 3.5rem;
            margin-bottom: 1.5rem;
            display: block;
            color: #007bff;
        }

        .admin-card .card-icon {
            color: #667eea;
        }

        .member-card .card-icon {
            color: #f5576c;
        }

        .card-title {
            font-size: 1.6rem;
            font-weight: 600;
            margin-bottom: 0.8rem;
            color: #333;
        }

        .card-description {
            font-size: 1rem;
            color: #6c757d;
            line-height: 1.5;
        }

        .footer {
            text-align: center;
            padding: 2rem 1rem;
            color: #6c757d;
            font-size: 0.9rem;
            background: white;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.05);
        }

        @media (max-width: 768px) {
            .header {
                padding: 1rem;
                flex-direction: column;
                gap: 1rem;
            }

            .company-name {
                font-size: 1.5rem;
            }

            .welcome-section {
                padding: 2rem 1.5rem;
                margin: 1rem;
            }

            .welcome-title {
                font-size: 2rem;
            }

            .action-buttons {
                flex-direction: column;
                gap: 1.5rem;
            }

            .action-card {
                min-width: auto;
                padding: 2rem 1.5rem;
            }
        }

        /* Loading animation for better UX */
        .action-card:active {
            transform: translateY(-4px);
            transition: transform 0.1s ease;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo-section">
            <div class="logo-container">
                <img src="assets/images/act.jpg" alt="ACT Logo" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                <div style="display:none; color:#007bff; font-weight:bold; font-size:1.4rem;">ACT</div>
            </div>
            <div class="company-name">ACT Billing</div>
        </div>
    </header>

    <main class="main-content">
        <div class="welcome-section">
            <h1 class="welcome-title">Welcome to <span class="highlight">Applied Computer Technology</span></h1>
            <p class="welcome-subtitle">
                Your comprehensive billing and management solution. Choose your access level to get started with our secure platform.
            </p>
            
            <div class="action-buttons">
            <a href="../auth/login.php?force=true" class="action-card admin-card">
                    <i class="fas fa-user-shield card-icon"></i>
                    <div class="card-title">Admin Login</div>
                    <div class="card-description">Access administrative dashboard, manage users, billing, and system settings</div>
                </a>
                
                <a href="../auth/member_register.php" class="action-card member-card">
                    <i class="fas fa-user-plus card-icon"></i>
                    <div class="card-title">Member Register</div>
                    <div class="card-description">Create a new membership account to access member services and billing</div>
                </a>
            </div>
        </div>
    </main>

    <footer class="footer">
        <p>&copy; 2025 Applied Computer Technology. All rights reserved. | Secure Billing Management System</p>
    </footer>
</body>
</html>