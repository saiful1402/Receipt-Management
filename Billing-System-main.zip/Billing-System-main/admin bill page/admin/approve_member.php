<?php
session_start();
require_once "../config/database.php";

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit();
}

$id = $_GET['id'] ?? 0;
$action = $_GET['action'] ?? '';

if ($id && ($action === 'approve' || $action === 'reject')) {
    $status = ($action === 'approve') ? 'active' : 'inactive';
    $stmt = $conn->prepare("UPDATE members SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
}

header('Location: pending_members.php');
exit();