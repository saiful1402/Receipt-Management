<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if (isset($_POST['id'], $_POST['status'])) {
    $id = intval($_POST['id']);
    $status = $_POST['status'];

    // Valid statuses from DB
    $validStatuses = ['pending', 'active', 'inactive', 'suspended'];
    if (!in_array($status, $validStatuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid status']);
        exit;
    }
     $warning = '';

    // If approving, check membership_type
    if ($status === 'active') {
        $checkStmt = $conn->prepare("SELECT membership_type FROM members WHERE id = ?");
        $checkStmt->bind_param("i", $id);
        $checkStmt->execute();
        $checkStmt->bind_result($membership_type);
        $checkStmt->fetch();
        $checkStmt->close();

        if (empty($membership_type)) {
            $warning = 'Activated, but membership type is missing';
            // exit;
        }
    }

    // Update status
    $stmt = $conn->prepare("UPDATE members SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    // if ($stmt->execute()) {
    //     echo json_encode(['success' => true]);
    if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'affected' => $stmt->affected_rows, // ✅ debug info
        'id' => $id,
        'status' => $status,
        'warning' => $warning
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Database update failed'
    ]);
}
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
}