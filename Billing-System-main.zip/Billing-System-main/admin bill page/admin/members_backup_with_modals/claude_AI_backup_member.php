<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config/database.php'; // adjust path

// Security check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit();
}

$message = '';
$error = '';

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'add_member') {
        try {
            // Generate member ID
            $stmt = $conn->prepare("SELECT MAX(CAST(SUBSTRING(member_id, 4) AS UNSIGNED)) as max_num FROM members WHERE member_id LIKE 'MEM%'");
            $stmt->execute();
            $result = $stmt->get_result();
            $maxNum = $result->fetch_assoc()['max_num'] ?? 0;
            $newMemberNum = str_pad($maxNum + 1, 4, '0', STR_PAD_LEFT);
            $memberId = 'MEM' . $newMemberNum;
            $stmt->close();

            $stmt = $conn->prepare("INSERT INTO members (member_id, first_name, last_name, email, phone, address, country, city, membership_type, status, amount, registration_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("ssssssssssd", $memberId, $_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['phone'], $_POST['address'], $_POST['country'], $_POST['city'], $_POST['membership_type'], $_POST['status'], $_POST['amount']);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Member added successfully!']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error adding member: ' . $stmt->error]);
            }
            $stmt->close();
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
        exit();
    }
    
    if ($_POST['action'] === 'update_member') {
        try {
            $stmt = $conn->prepare("UPDATE members SET first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, city = ?, membership_type = ?, status = ? WHERE id = ?");
            $stmt->bind_param("ssssssssi", $_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['phone'], $_POST['address'], $_POST['city'], $_POST['membership_type'], $_POST['status'], $_POST['member_id']);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Member updated successfully!']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error updating member: ' . $stmt->error]);
            }
            $stmt->close();
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
        exit();
    }
    
    if ($_POST['action'] === 'get_member') {
        try {
            $stmt = $conn->prepare("SELECT * FROM members WHERE id = ?");
            $stmt->bind_param("i", $_POST['member_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            $member = $result->fetch_assoc();
            $stmt->close();
            
            if ($member) {
                echo json_encode(['success' => true, 'member' => $member]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Member not found']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
        exit();
    }
}

// Handle delete
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $stmt = $conn->prepare("DELETE FROM members WHERE id = ?");
    $stmt->bind_param("i", $_GET['id']);
    $stmt->execute();
    $stmt->close();
    $message = 'Member deleted successfully!';
}

// Filter parameters
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$status = $_GET['status'] ?? '';
$membershipType = $_GET['membership_type'] ?? '';
$search = $_GET['search'] ?? '';

// Build query
$whereConditions = [];
$params = [];

if ($startDate && $endDate) {
    $whereConditions[] = "DATE(registration_date) BETWEEN ? AND ?";
    $params[] = $startDate;
    $params[] = $endDate;
}

if ($status) {
    $whereConditions[] = "status = ?";
    $params[] = $status;
}

if ($membershipType) {
    $whereConditions[] = "membership_type = ?";
    $params[] = $membershipType;
}

if ($search) {
    $whereConditions[] = "(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR member_id LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

$sql = "
    SELECT * FROM members
    $whereClause
    ORDER BY 
      CASE status
        WHEN 'pending' THEN 1
        WHEN 'active' THEN 2
        WHEN 'inactive' THEN 3
        WHEN 'suspended' THEN 4
        ELSE 5
      END,
      registration_date DESC
";
$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$members = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Count query
$sqlCount = "SELECT COUNT(*) as count FROM members $whereClause";
$countStmt = $conn->prepare($sqlCount);

if (!empty($params)) {
    $countStmt->bind_param($types, ...$params);
}

$countStmt->execute();
$countResult = $countStmt->get_result();
$filteredCount = $countResult->fetch_assoc()['count'];
$countStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members Management - Billing Software</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            padding: 12px 20px;
            border-radius: 6px;
            font-size: 14px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            z-index: 9999;
            opacity: 0.95;
            transition: opacity 0.3s ease-in-out;
        }

        .highlight-green { background-color: #d4edda !important; transition: background-color 0.5s ease; }
        .highlight-red { background-color: #f8d7da !important; transition: background-color 0.5s ease; }
        .highlight-orange { background-color: #fff3cd !important; transition: background-color 0.5s ease; }

        .toast-error { background: #dc3545; }
        .toast-warning { background: #ffc107; color: #212529; }
        .toast-success { background: #28a745; }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s ease;
        }

        .modal.show {
            display: block;
        }

        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 0;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            animation: slideIn 0.3s ease;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            background-color: #007bff;
            color: white;
            padding: 15px 20px;
            border-radius: 8px 8px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            margin: 0;
            font-size: 18px;
        }

        .close {
            color: white;
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
            border: none;
            background: none;
            padding: 0;
            line-height: 1;
        }

        .close:hover {
            opacity: 0.8;
        }

        .modal-body {
            padding: 20px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }

        .form-grid.single-column {
            grid-template-columns: 1fr;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .btn-modal {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .btn-primary-modal {
            background-color: #007bff;
            color: white;
        }

        .btn-primary-modal:hover {
            background-color: #0056b3;
        }

        .btn-secondary-modal {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary-modal:hover {
            background-color: #545b62;
        }

        .btn-primary-modal:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .loading {
            opacity: 0.7;
            pointer-events: none;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .modal-content {
                margin: 2% auto;
                width: 95%;
                max-height: 95vh;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Admin Header -->
    <header class="admin-header">
        <nav class="admin-nav">
            <h1>Billing Software Admin</h1>
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="members.php">Members</a>
                <a href="invoices.php">Invoices</a>
                <a href="reports.php">Reports</a>
                <a href="../auth/logout.php" class="logout-btn">Logout</a>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h2>Members Management</h2>
            <div class="page-actions">
                <button onclick="openModal('addMemberModal')" class="btn btn-primary">Add New Member</button>
            </div>
        </div>

        <?php if($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" class="filter-form">
                <div class="filter-group">
                    <label for="start_date">Start Date</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
                </div>
                
                <div class="filter-group">
                    <label for="end_date">End Date</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
                </div>
                
                <div class="filter-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="">All Status</option>
                        <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        <option value="suspended" <?php echo $status === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="membership_type">Membership Type</label>
                    <select id="membership_type" name="membership_type">
                        <option value="">All Types</option>
                        <option value="life member" <?php echo $membershipType === 'life member' ? 'selected' : ''; ?>>Life Member</option>
                        <option value="executive member" <?php echo $membershipType === 'executive member' ? 'selected' : ''; ?>>Executive Member</option>
                        <option value="associate member" <?php echo $membershipType === 'associate member' ? 'selected' : ''; ?>>Associate Member</option>
                        <option value="student member" <?php echo $membershipType === 'student member' ? 'selected' : ''; ?>>Student Member</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="search">Search</label>
                    <input type="text" id="search" name="search" placeholder="Search by name, email, or ID" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                
                <div class="filter-group">
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <a href="members.php" class="btn btn-secondary">Clear</a>
                </div>
            </form>
        </div>

        <!-- Results Summary -->
        <div class="results-summary">
            <p>Showing <?php echo $filteredCount; ?> member(s)</p>
        </div>

        <!-- Members Table -->
        <div class="table-container">
            <div class="table-header">
                <h3>Members List</h3>
                <div class="table-actions">
                    <button onclick="exportMembers()" class="btn btn-secondary btn-sm">Export</button>
                </div>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>Member ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Membership</th>
                        <th>Status</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($members as $member): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($member['member_id']); ?></td>
                        <td><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($member['email']); ?></td>
                        <td><?php echo htmlspecialchars($member['phone']); ?></td>
                        <td><?php echo ucfirst(htmlspecialchars($member['membership_type'])); ?></td>
                        <td>
                            <select class="status-select" data-id="<?php echo $member['id']; ?>">
                                <option value="pending"   <?php echo $member['status'] === 'pending'   ? 'selected' : ''; ?>>Pending</option>
                                <option value="active"    <?php echo $member['status'] === 'active'    ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive"  <?php echo $member['status'] === 'inactive'  ? 'selected' : ''; ?>>Inactive</option>
                                <option value="suspended" <?php echo $member['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                            </select>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($member['registration_date'])); ?></td>
                        <td>
                            <button onclick="openEditModalNew(<?php echo $member['id']; ?>)" class="btn btn-warning btn-sm">Edit</button>
                            <button onclick="deleteMember(<?php echo $member['id']; ?>)" class="btn btn-danger btn-sm">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Member Modal -->
    <div id="addMemberModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Add New Member</h3>
                <button class="close" onclick="closeModal('addMemberModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="addMemberForm">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="add_first_name">First Name *</label>
                            <input type="text" id="add_first_name" name="first_name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="add_last_name">Last Name *</label>
                            <input type="text" id="add_last_name" name="last_name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="add_email">Email *</label>
                            <input type="email" id="add_email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="add_phone">Phone</label>
                            <input type="tel" id="add_phone" name="phone">
                        </div>
                        
                        <div class="form-group">
                            <label for="add_country">Country</label>
                            <input type="text" id="add_country" name="country">
                        </div>
                        
                        <div class="form-group">
                            <label for="add_city">City</label>
                            <input type="text" id="add_city" name="city">
                        </div>
                        
                        <div class="form-group">
                            <label for="add_membership_type">Membership Type *</label>
                            <select id="add_membership_type" name="membership_type" required>
                                <option value="">Select Type</option>
                                <option value="life member">Life Member</option>
                                <option value="executive member">Executive Member</option>
                                <option value="associate member">Associate Member</option>
                                <option value="student member">Student Member</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="add_status">Status *</label>
                            <select id="add_status" name="status" required>
                                <option value="pending">Pending</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="suspended">Suspended</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="add_amount">Amount</label>
                            <input type="number" id="add_amount" name="amount" step="0.01" min="0">
                        </div>
                    </div>
                    
                    <div class="form-grid single-column">
                        <div class="form-group">
                            <label for="add_address">Address</label>
                            <textarea id="add_address" name="address" rows="3"></textarea>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-modal btn-secondary-modal" onclick="closeModal('addMemberModal')">Cancel</button>
                <button type="button" class="btn-modal btn-primary-modal" onclick="submitAddForm()">Add Member</button>
            </div>
        </div>
    </div>

    <!-- Edit Member Modal -->
    <div id="editMemberModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Member</h3>
                <button class="close" onclick="closeModal('editMemberModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="editMemberForm">
                    <input type="hidden" id="edit_member_id" name="member_id">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="edit_first_name">First Name *</label>
                            <input type="text" id="edit_first_name" name="first_name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_last_name">Last Name *</label>
                            <input type="text" id="edit_last_name" name="last_name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_email">Email *</label>
                            <input type="email" id="edit_email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_phone">Phone</label>
                            <input type="tel" id="edit_phone" name="phone">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_city">City</label>
                            <input type="text" id="edit_city" name="city">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_membership_type">Membership Type *</label>
                            <select id="edit_membership_type" name="membership_type" required>
                                <option value="">Select Type</option>
                                <option value="life member">Life Member</option>
                                <option value="executive member">Executive Member</option>
                                <option value="associate member">Associate Member</option>
                                <option value="student member">Student Member</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_status">Status *</label>
                            <select id="edit_status" name="status" required>
                                <option value="pending">Pending</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="suspended">Suspended</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-grid single-column">
                        <div class="form-group">
                            <label for="edit_address">Address</label>
                            <textarea id="edit_address" name="address" rows="3"></textarea>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-modal btn-secondary-modal" onclick="closeModal('editMemberModal')">Cancel</button>
                <button type="button" class="btn-modal btn-primary-modal" onclick="submitEditForm()">Update Member</button>
            </div>
        </div>
    </div>

    <script>
        // Toast notification function
        function showToast(message, type = 'success') {
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            toast.textContent = message;
            document.body.appendChild(toast);
            
            setTimeout(() => {
                toast.remove();
            }, 3000);
        }

        // Modal Functions
        function openAddModal() {
            document.getElementById('addMemberModal').classList.add('show');
            document.getElementById('addMemberForm').reset();
        }

        function closeAddModal() {
            document.getElementById('addMemberModal').classList.remove('show');
        }

        function openEditModal(memberId) {
            // Fetch member data
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    closeModal('editMemberModal');
                    // Reload page to show updated member
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error updating member', 'error');
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Update Member';
            });
    </script>
    
    <script>
        // Modal Functions - Updated to work with existing admin.js
        function openEditModalNew(memberId) {
            console.log('openEditModalNew called with ID:', memberId); // Debug log
            
            // Fetch member data
            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `ajax=1&action=get_member&member_id=${memberId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const member = data.member;
                    document.getElementById('edit_member_id').value = member.id;
                    document.getElementById('edit_first_name').value = member.first_name || '';
                    document.getElementById('edit_last_name').value = member.last_name || '';
                    document.getElementById('edit_email').value = member.email || '';
                    document.getElementById('edit_phone').value = member.phone || '';
                    document.getElementById('edit_city').value = member.city || '';
                    document.getElementById('edit_address').value = member.address || '';
                    document.getElementById('edit_membership_type').value = member.membership_type || '';
                    document.getElementById('edit_status').value = member.status || '';
                    
                    openModal('editMemberModal');
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error fetching member data', 'error');
            });
        }
        }

        function deleteMember(memberId) {
            if (confirm('Are you sure you want to delete this member? This action cannot be undone.')) {
                window.location.href = `members.php?action=delete&id=${memberId}`;
            }
        }

        // Close modal when clicking outside - removed to avoid conflict with admin.js
        // The existing admin.js already handles this

        // Close modal with Escape key - removed to avoid conflict
        // The existing admin.js already handles this

        // Export function (placeholder - you can implement actual export logic)
        function exportMembers() {
            showToast('Export feature coming soon!', 'warning');
        }

        // Status update function (if you want to keep the inline status update)
        function updateStatus(memberId, newStatus) {
            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `ajax=1&action=update_status&member_id=${memberId}&status=${newStatus}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Status updated successfully!', 'success');
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error updating status', 'error');
            });
        }

        // Auto-submit status changes
        document.addEventListener('DOMContentLoaded', function() {
            const statusSelects = document.querySelectorAll('.status-select');
            statusSelects.forEach(select => {
                select.addEventListener('change', function() {
                    const memberId = this.getAttribute('data-id');
                    const newStatus = this.value;
                    updateStatus(memberId, newStatus);
                });
            });
        });
    </script>
    
    <script src="../assets/js/admin.js"></script>
</body>
</html>'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `ajax=1&action=get_member&member_id=${memberId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const member = data.member;
                    document.getElementById('edit_member_id').value = member.id;
                    document.getElementById('edit_first_name').value = member.first_name || '';
                    document.getElementById('edit_last_name').value = member.last_name || '';
                    document.getElementById('edit_email').value = member.email || '';
                    document.getElementById('edit_phone').value = member.phone || '';
                    document.getElementById('edit_city').value = member.city || '';
                    document.getElementById('edit_address').value = member.address || '';
                    document.getElementById('edit_membership_type').value = member.membership_type || '';
                    document.getElementById('edit_status').value = member.status || '';
                    
                    document.getElementById('editMemberModal').classList.add('show');
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error fetching member data', 'error');
            });
        }

        function closeEditModal() {
            document.getElementById('editMemberModal').classList.remove('show');
        }

        function submitAddForm() {
            const form = document.getElementById('addMemberForm');
            
            // Basic validation
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = '#dc3545';
                    isValid = false;
                } else {
                    field.style.borderColor = '#ddd';
                }
            });
            
            if (!isValid) {
                showToast('Please fill in all required fields', 'error');
                return;
            }
            
            const formData = new FormData(form);
            formData.append('ajax', '1');
            formData.append('action', 'add_member');

            // Get the submit button and disable it during submission
            const submitBtn = document.querySelector('#addMemberModal .btn-primary-modal');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Adding...';

            console.log('Submitting form...'); // Debug log

            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('Response received:', response); // Debug log
                return response.json();
            })
            .then(data => {
                console.log('Data received:', data); // Debug log
                if (data.success) {
                    showToast(data.message, 'success');
                    closeModal('addMemberModal');
                    // Reload page to show new member
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error adding member', 'error');
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Add Member';
            });
        }

        function submitEditForm() {
            const form = document.getElementById('editMemberForm');
            const formData = new FormData(form);
            formData.append('ajax', '1');
            formData.append('action', 'update_member');

            // Disable button during submission
            const submitBtn = event.target;
            submitBtn.disabled = true;
            submitBtn.textContent = 'Updating...';

            fetch(window.location.href, {
                method: