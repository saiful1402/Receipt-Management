<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     echo "<pre>DEBUG: PHP got POST\n";
//     print_r($_POST);
//     echo "</pre>";
    // die("🚨 Stopped here (test mode) 🚨");
    // exit;
// }
session_start();
require_once '../config/database.php'; // adjust path

// Security check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit();
}

$message = '';
$error = '';

// Handle delete
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    // try {
    //     $pdo = getDBConnection();
    //     $stmt = $pdo->prepare("DELETE FROM members WHERE id = ?");
    //     $stmt->execute([$_GET['id']]);
    //     $message = 'Member deleted successfully';
    // } catch (PDOException $e) {
    //     $error = 'Error deleting member: ' . $e->getMessage();
    // }
    $stmt = $conn->prepare("DELETE FROM members WHERE id = ?");
    $stmt->bind_param("i", $_GET['id']);
    $stmt->execute();
    $stmt->close();
}
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     echo "<pre>DEBUG: POST received\n";
//     print_r($_POST);
//     echo "</pre>";
//     exit;  // stop here to confirm
// }

// Handle add/edit form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     // DEBUG: Let's see what's being received
    // error_log("POST received: " . print_r($_POST, true));
    // echo "<pre>";
    // print_r($_POST);
    // echo "</pre>";
    // exit;
    $action = $_POST['action'] ?? '';
    error_log("Action: " . $action);
    // try {
    //     $pdo = getDBConnection();

    //     if ($action === 'add') {
    //         $memberId = generateMemberId();
    //         $stmt = $pdo->prepare("
    //             INSERT INTO members (member_id, first_name, last_name, email, phone, address, country, city, membership_type, status) 
    //             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    //         ");
    //         $stmt->execute([
    //             $memberId,
    //             $_POST['first_name'],
    //             $_POST['last_name'],
    //             $_POST['email'],
    //             $_POST['phone'],
    //             $_POST['address'],
    //             $_POST['country'],
    //             $_POST['city'],
    //             $_POST['membership_type'],
    //             $_POST['status']
    //         ]);
    //         $message = 'Member added successfully';
    //     } elseif ($action === 'edit') {
    //         $stmt = $pdo->prepare("
    //             UPDATE members SET 
    //                 first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, 
    //                  city = ?, membership_type = ?, status = ?
    //             WHERE id = ?
    //         ");
    //         $stmt->execute([
    //             $_POST['first_name'],
    //             $_POST['last_name'],
    //             $_POST['email'],
    //             $_POST['phone'],
    //             $_POST['address'],
    //             // $_POST['country'],
    //             $_POST['city'],
    //             $_POST['membership_type'],
    //             $_POST['status'],
    //             $_POST['id']
    //         ]);
    //         $message = 'Member updated successfully';
    //     }
    // } catch (PDOException $e) {
    //     $error = 'Database Error: ' . $e->getMessage();
    // }
    if ($action === 'add') {
        error_log("Processing ADD action");
    $memberId = generateMemberId();
    // $memberId = uniqid("M");  // quick test ID like M64e4f2a3d12f1
    error_log("Generated Member ID: " . $memberId);
    // $amount = 0; // default for now
    $amount = $_POST['amount'];
    error_log("Amount: " . $amount);

    $stmt = $conn->prepare("
        INSERT INTO members 
        (member_id, first_name, last_name, email, phone, address, country, city, membership_type, amount, status, registration_date, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ");
    if (!$stmt) {
        error_log("❌ Prepare failed: " . $conn->error);
        die("❌ Prepare failed: " . $conn->error);
    }
    
    $amount_float = (float)$amount;  // Store in variable first
    $stmt->bind_param(
        "sssssssssds",
        $memberId,
        $_POST['first_name'],
        $_POST['last_name'],
        $_POST['email'],
        $_POST['phone'],
        $_POST['address'],
        $_POST['country'],
        $_POST['city'],
        $_POST['membership_type'],
        // (float)$amount,
        $amount_float,
        $_POST['status']
        //$_POST['status']  // Add this line - duplicate for the missing parameter
    );

    if ($stmt->execute()) {
         error_log("✅ Member inserted successfully!");
    $message = "✅ Member added successfully!";
        } else {
            error_log("❌ Insert failed: " . $stmt->error);
            $error = "❌ Insert failed: " . $stmt->error;
        }
//     echo "✅ Member inserted successfully!";
// } else {
//     echo "❌ Insert failed: " . $stmt->error;
// }
    $stmt->close();
} elseif ($action === 'edit') {
    // echo "Inside ADD block<br>";
    $stmt = $conn->prepare("
    UPDATE members SET 
        first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, 
        city = ?, membership_type = ?, status = ?
    WHERE id = ?
");
$stmt->bind_param(
    "ssssssssi",
    $_POST['first_name'],
    $_POST['last_name'],
    $_POST['email'],
    $_POST['phone'],
    $_POST['address'],
    $_POST['city'],
    $_POST['membership_type'],
    $_POST['status'],
    $_POST['id']
);
// $stmt->execute();
// $stmt->close();
// $message = 'Member updated successfully';
if ($stmt->execute()) {
            $message = "✅ Member updated successfully!";
        } else {
            $error = "❌ Update failed: " . $stmt->error;
        }

        $stmt->close();
}
}
// Filter parameters
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$status = $_GET['status'] ?? '';
$membershipType = $_GET['membership_type'] ?? '';
$search = $_GET['search'] ?? '';

// Build query
$whereConditions = [];
$params = [];

if ($startDate && $endDate) {
    $whereConditions[] = "DATE(registration_date) BETWEEN ? AND ?";
    $params[] = $startDate;
    $params[] = $endDate;
}

if ($status) {
    $whereConditions[] = "status = ?";
    $params[] = $status;
}

if ($membershipType) {
    $whereConditions[] = "membership_type = ?";
    $params[] = $membershipType;
}

if ($search) {
    $whereConditions[] = "(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR member_id LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

// try {
//     $pdo = getDBConnection();
//     $stmt = $pdo->prepare("SELECT * FROM members $whereClause ORDER BY created_at DESC");
//     $stmt->execute($params);
//     $members = $stmt->fetchAll();

//     $countStmt = $pdo->prepare("SELECT COUNT(*) as count FROM members $whereClause");
//     $countStmt->execute($params);
//     $filteredCount = $countStmt->fetch()['count'];
// } catch (PDOException $e) {
//     $error = 'Database error: ' . $e->getMessage();
//     $members = [];
//     $filteredCount = 0;
// }
// $sql = "SELECT * FROM members $whereClause ORDER BY created_at ASC";
$sql = "
    SELECT * FROM members
    $whereClause
    ORDER BY 
      CASE status
        WHEN 'pending' THEN 1
        WHEN 'active' THEN 2
        WHEN 'inactive' THEN 3
        WHEN 'suspended' THEN 4
        ELSE 5
      END,
      registration_date DESC
";
$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$members = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Count query
$sqlCount = "SELECT COUNT(*) as count FROM members $whereClause";
$countStmt = $conn->prepare($sqlCount);

if (!empty($params)) {
    $countStmt->bind_param($types, ...$params);
}

$countStmt->execute();
$countResult = $countStmt->get_result();
$filteredCount = $countResult->fetch_assoc()['count'];
$countStmt->close();
?>

<!-- Your HTML and modal code from the old members.php goes here exactly as it was -->



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members Management - Billing Software</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    .toast {
  position: fixed;          /* Make it float */
  bottom: 20px;                /* Distance from top */
  right: 20px;              /* Distance from right */
  background: #28a745;      /* Default green success */
  color: white;
  padding: 12px 20px;
  border-radius: 6px;
  font-size: 14px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  z-index: 9999;            /* On top of everything */
  opacity: 0.95;
  transition: opacity 0.3s ease-in-out;
}
 Highlight colors 
.highlight-green { background-color: #d4edda !important; transition: background-color 0.5s ease; }
.highlight-red { background-color: #f8d7da !important; transition: background-color 0.5s ease; }
.highlight-orange { background-color: #fff3cd !important; transition: background-color 0.5s ease; }
.toast-error {
     background: #dc3545;  /* red */
}
.toast-warning {
    background: #ffc107;  /* yellow */
    color: #212529;
}
.toast-success {
     background: #28a745;  /* green */
}
</style>
</head>
<body>
    <!-- Admin Header -->
    <header class="admin-header">
        <nav class="admin-nav">
            <h1>Billing Software Admin</h1>
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="members.php">Members</a>
                <a href="invoices.php">Invoices</a>
                <a href="reports.php">Reports</a>
                <!--<span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>-->
                <a href="../auth/logout.php" class="logout-btn">Logout</a>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h2>Members Management</h2>
            <div class="page-actions">
                <button onclick="openModal('addMemberModal')" class="btn btn-primary">Add New Member</button>
                <!--<a href="#testAddForm" class="btn btn-primary">Add New Member</a>-->
            </div>
        </div>

        <?php if($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" class="filter-form">
                <div class="filter-group">
                    <label for="start_date">Start Date</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
                </div>
                
                <div class="filter-group">
                    <label for="end_date">End Date</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
                </div>
                
                <div class="filter-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="">All Status</option>
                        <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        <option value="suspended" <?php echo $status === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="membership_type">Membership Type</label>
                    <select id="membership_type" name="membership_type">
                        <option value="">All Types</option>
                        <option value="life member" <?php echo $membershipType === 'life member' ? 'selected' : ''; ?>>Life Member</option>
                        <option value="executive member" <?php echo $membershipType === 'executive member' ? 'selected' : ''; ?>>Executive Member</option>
                        <option value="associate member" <?php echo $membershipType === 'associate member' ? 'selected' : ''; ?>>Associate Member</option>
                        <option value="student member" <?php echo $membershipType === 'student member' ? 'selected' : ''; ?>>Student Member</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="search">Search</label>
                    <input type="text" id="search" name="search" placeholder="Search by name, email, or ID" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                
                <div class="filter-group">
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <a href="members.php" class="btn btn-secondary">Clear</a>
                </div>
            </form>
        </div>

        <!-- Results Summary -->
        <div class="results-summary">
            <p>Showing <?php echo $filteredCount; ?> member(s)</p>
        </div>

        <!-- Members Table -->
        <div class="table-container">
            <div class="table-header">
                <h3>Members List</h3>
                <div class="table-actions">
                    <button onclick="exportMembers()" class="btn btn-secondary btn-sm">Export</button>
                </div>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>Member ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Membership</th>
                        <th>Status</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($members as $member): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($member['member_id']); ?></td>
                        <td><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($member['email']); ?></td>
                        <td><?php echo htmlspecialchars($member['phone']); ?></td>
                        <td><?php echo ucfirst(htmlspecialchars($member['membership_type'])); ?></td>
                        <td>
                            <!--<span class="badge badge-<?php echo $member['status'] === 'active' ? 'active' : 'inactive'; ?>">-->
                            <!--    <?php echo ucfirst(htmlspecialchars($member['status'])); ?>-->
                            <!--</span>-->
                            <!--<select onchange="updateStatus(<?php echo $member['id']; ?>, this.value)">-->
                            <!--    <option value="pending"   <?php echo $member['status'] === 'pending'   ? 'selected' : ''; ?>>Pending</option>-->
                            <!--    <option value="active"    <?php echo $member['status'] === 'active'    ? 'selected' : ''; ?>>Active</option>-->
                            <!--    <option value="inactive"  <?php echo $member['status'] === 'inactive'  ? 'selected' : ''; ?>>Inactive</option>-->
                            <!--    <option value="suspended" <?php echo $member['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>-->
                            <!--</select>-->
                            <select class="status-select" data-id="<?php echo $member['id']; ?>">
                                <option value="pending"   <?php echo $member['status'] === 'pending'   ? 'selected' : ''; ?>>Pending</option>
                                <option value="active"    <?php echo $member['status'] === 'active'    ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive"  <?php echo $member['status'] === 'inactive'  ? 'selected' : ''; ?>>Inactive</option>
                                <option value="suspended" <?php echo $member['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                            </select>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($member['registration_date'])); ?></td>
                        <td>
                            <button onclick='editMember(<?php echo json_encode($member); ?>)' class="btn btn-warning btn-sm">Edit</button>
                            <button onclick="deleteMember(<?php echo $member['id']; ?>)" class="btn btn-danger btn-sm">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Member Modal -->
    <!-- Add Member Modal - FIXED VERSION -->
<div id="addMemberModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Add New Member</h3>
            <span class="close" onclick="closeModal('addMemberModal')">&times;</span>
        </div>
        <form method="POST" id="addMemberForm" action="members.php">
            <input type="hidden" name="action" value="add">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" id="first_name" name="first_name" required>
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" id="last_name" name="last_name" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" name="phone">
                </div>
            </div>
            
            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" rows="3"></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="country">Country</label>
                    <input list="countryList" id="country" name="country" required>
                    <datalist id="countryList">
  <option value="Afghanistan">
  <option value="Albania">
  <option value="Algeria">
  <option value="Andorra">
  <option value="Angola">
  <option value="Argentina">
  <option value="Armenia">
  <option value="Australia">
  <option value="Austria">
  <option value="Azerbaijan">
  <option value="Bahamas">
  <option value="Bahrain">
  <option value="Bangladesh">
  <option value="Barbados">
  <option value="Belarus">
  <option value="Belgium">
  <option value="Belize">
  <option value="Benin">
  <option value="Bhutan">
  <option value="Bolivia">
  <option value="Bosnia and Herzegovina">
  <option value="Botswana">
  <option value="Brazil">
  <option value="Brunei">
  <option value="Bulgaria">
  <option value="Burkina Faso">
  <option value="Burundi">
  <option value="Cambodia">
  <option value="Cameroon">
  <option value="Canada">
  <option value="Cape Verde">
  <option value="Central African Republic">
  <option value="Chad">
  <option value="Chile">
  <option value="China">
  <option value="Colombia">
  <option value="Comoros">
  <option value="Costa Rica">
  <option value="Croatia">
  <option value="Cuba">
  <option value="Cyprus">
  <option value="Czech Republic">
  <option value="Denmark">
  <option value="Djibouti">
  <option value="Dominica">
  <option value="Dominican Republic">
  <option value="Ecuador">
  <option value="Egypt">
  <option value="El Salvador">
  <option value="Equatorial Guinea">
  <option value="Eritrea">
  <option value="Estonia">
  <option value="Eswatini">
  <option value="Ethiopia">
  <option value="Fiji">
  <option value="Finland">
  <option value="France">
  <option value="Gabon">
  <option value="Gambia">
  <option value="Georgia">
  <option value="Germany">
  <option value="Ghana">
  <option value="Greece">
  <option value="Grenada">
  <option value="Guatemala">
  <option value="Guinea">
  <option value="Guyana">
  <option value="Haiti">
  <option value="Honduras">
  <option value="Hungary">
  <option value="Iceland">
  <option value="India">
  <option value="Indonesia">
  <option value="Iran">
  <option value="Iraq">
  <option value="Ireland">
  <option value="Israel">
  <option value="Italy">
  <option value="Jamaica">
  <option value="Japan">
  <option value="Jordan">
  <option value="Kazakhstan">
  <option value="Kenya">
  <option value="Kiribati">
  <option value="Kuwait">
  <option value="Kyrgyzstan">
  <option value="Laos">
  <option value="Latvia">
  <option value="Lebanon">
  <option value="Lesotho">
  <option value="Liberia">
  <option value="Libya">
  <option value="Liechtenstein">
  <option value="Lithuania">
  <option value="Luxembourg">
  <option value="Madagascar">
  <option value="Malawi">
  <option value="Malaysia">
  <option value="Maldives">
  <option value="Mali">
  <option value="Malta">
  <option value="Marshall Islands">
  <option value="Mauritania">
  <option value="Mauritius">
  <option value="Mexico">
  <option value="Micronesia">
  <option value="Moldova">
  <option value="Monaco">
  <option value="Mongolia">
  <option value="Montenegro">
  <option value="Morocco">
  <option value="Mozambique">
  <option value="Myanmar">
  <option value="Namibia">
  <option value="Nauru">
  <option value="Nepal">
  <option value="Netherlands">
  <option value="New Zealand">
  <option value="Nicaragua">
  <option value="Niger">
  <option value="Nigeria">
  <option value="North Korea">
  <option value="North Macedonia">
  <option value="Norway">
  <option value="Oman">
  <option value="Pakistan">
  <option value="Palau">
  <option value="Palestine">
  <option value="Panama">
  <option value="Papua New Guinea">
  <option value="Paraguay">
  <option value="Peru">
  <option value="Philippines">
  <option value="Poland">
  <option value="Portugal">
  <option value="Qatar">
  <option value="Romania">
  <option value="Russia">
  <option value="Rwanda">
  <option value="Saint Kitts and Nevis">
  <option value="Saint Lucia">
  <option value="Saint Vincent and the Grenadines">
  <option value="Samoa">
  <option value="San Marino">
  <option value="Sao Tome and Principe">
  <option value="Saudi Arabia">
  <option value="Senegal">
  <option value="Serbia">
  <option value="Seychelles">
  <option value="Sierra Leone">
  <option value="Singapore">
  <option value="Slovakia">
  <option value="Slovenia">
  <option value="Solomon Islands">
  <option value="Somalia">
  <option value="South Africa">
  <option value="South Korea">
  <option value="South Sudan">
  <option value="Spain">
  <option value="Sri Lanka">
  <option value="Sudan">
  <option value="Suriname">
  <option value="Sweden">
  <option value="Switzerland">
  <option value="Syria">
  <option value="Taiwan">
  <option value="Tajikistan">
  <option value="Tanzania">
  <option value="Thailand">
  <option value="Togo">
  <option value="Tonga">
  <option value="Trinidad and Tobago">
  <option value="Tunisia">
  <option value="Turkey">
  <option value="Turkmenistan">
  <option value="Tuvalu">
  <option value="Uganda">
  <option value="Ukraine">
  <option value="United Arab Emirates">
  <option value="United Kingdom">
  <option value="United States">
  <option value="Uruguay">
  <option value="Uzbekistan">
  <option value="Vanuatu">
  <option value="Vatican City">
  <option value="Venezuela">
  <option value="Vietnam">
  <option value="Yemen">
  <option value="Zambia">
  <option value="Zimbabwe">
</datalist>
                </div>
                <div class="form-group">
                    <label for="city">City</label>
                    <input type="text" id="city" name="city">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="membership_type">Membership Type</label>
                    <select id="membership_type" name="membership_type" required>
                        <option value="">-- Select Membership Type --</option>
                        <option value="life member">Life Member</option>
                        <option value="executive member">Executive Member</option>
                        <option value="associate member">Associate Member</option>
                        <option value="student member">Student Member</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="pending">Pending</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="suspended">Suspended</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                    <div class="form-group">
                        <label for="amount">Amount</label>
                        <input type="number" step="0.01" id="amount" name="amount" required>
                    </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Add Member</button>
                <button type="button" onclick="closeModal('addMemberModal')" class="btn btn-secondary">Cancel</button>
                <!-- Debug button -->
                <!--<button type="button" onclick="testSubmit()" class="btn btn-warning">Test Submit</button>-->
            </div>
            </div>
        </form>
    </div>
</div>

<!--<h3 id="testAddFormTitle">🚀 Test Add Member (No Modal)</h3>-->
<!--<form id="testAddForm" method="POST" action="members.php" onsubmit="alert('Submitting test form!'); return true;">-->
<!--    <input type="hidden" name="action" value="add">-->
    
<!--    <label>First Name</label><br>-->
<!--    <input type="text" name="first_name" ><br><br>-->
    
<!--    <label>Last Name</label><br>-->
<!--    <input type="text" name="last_name" ><br><br>-->
    
<!--    <label>Email</label><br>-->
<!--    <input type="email" name="email" ><br><br>-->
    
<!--    <label>Phone</label><br>-->
<!--    <input type="number" name="phone"><br><br>-->
    
<!--    <label >Address</label><br>-->
<!--    <textarea name="address" rows="3"></textarea><br><br>-->
    
<!--    <label>Country</label><br>-->
<!--    <input type="text" name="country" ><br><br>-->
    
<!--    <label>City</label><br>-->
<!--    <input type="text" name="city" ><br><br>-->
    
<!--    <label>Membership Type</label><br>-->
<!--    <select name="membership_type" >-->
<!--        <option value="">-- Select --</option>-->
<!--        <option value="life member">Life Member</option>-->
<!--        <option value="executive member">Executive Member</option>-->
<!--        <option value="associate member">Associate Member</option>-->
<!--        <option value="student member">Student Member</option>-->
<!--    </select><br><br>-->
<!--    <label>Amount</label><br>-->
<!--<input type="number" step="0.01" name="amount" ><br><br>-->
<!--    <label>Status</label><br>-->
<!--    <select name="status" >-->
<!--        <option value="pending">Pending</option>-->
<!--        <option value="active">Active</option>-->
<!--        <option value="inactive">Inactive</option>-->
<!--        <option value="suspended">Suspended</option>-->
<!--    </select><br><br>-->

<!--    <button type="submit">Submit Test</button>-->
<!--</form>-->

    <!-- Edit Member Modal -->
<div id="editMemberModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Edit Member</h3>
            <span class="close" onclick="closeModal('editMemberModal')">&times;</span>
        </div>

        <form method="POST" id="editMemberForm" action="members.php">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" id="edit_id" name="id">

            <div class="form-row">
                <div class="form-group">
                    <label for="edit_first_name">First Name</label>
                    <input type="text" id="edit_first_name" name="first_name" required>
                </div>
                <div class="form-group">
                    <label for="edit_last_name">Last Name</label>
                    <input type="text" id="edit_last_name" name="last_name" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="edit_email">Email</label>
                    <input type="email" id="edit_email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="edit_phone">Phone</label>
                    <input type="tel" id="edit_phone" name="phone">
                </div>
            </div>

            <div class="form-group">
                <label for="edit_address">Address</label>
                <textarea id="edit_address" name="address" rows="3"></textarea>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="edit_city">City</label>
                    <input type="text" id="edit_city" name="city">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="edit_membership_type">Membership Type</label>
                    <select id="edit_membership_type" name="membership_type" required>
                        <option value="">-- Select Membership Type --</option>
                        <option value="life member">Life Member</option>
                        <option value="executive member">Executive Member</option>
                        <option value="associate member">Associate Member</option>
                        <option value="student member">Student Member</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit_status">Status</label>
                    <select id="edit_status" name="status" required>
                        <option value="pending">Pending</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="suspended">Suspended</option>
                    </select>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Update Member</button>
                <button type="button" onclick="closeModal('editMemberModal')" class="btn btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>


    <script src="../assets/js/admin.js"></script>
         <script>
    // document.addEventListener('DOMContentLoaded', function() {
    //     const addForm = document.getElementById('addMemberForm');
    //     const submitBtn = addForm?.querySelector('button[type="submit"]');
        
    //     if (addForm && submitBtn) {
    //         addForm.addEventListener('submit', function(e) {
    //             e.preventDefault(); // Prevent default form submission
                
    //             // Show loading state
    //             submitBtn.disabled = true;
    //             submitBtn.textContent = 'Adding...';
                
    //             // Validate form
    //             if (!addForm.checkValidity()) {
    //                 addForm.reportValidity();
    //                 submitBtn.disabled = false;
    //                 submitBtn.textContent = 'Add Member';
    //                 return;
    //             }
                
    //             // Collect form data
    //             const formData = new FormData(addForm);
                
    //             // Send AJAX request
    //             fetch('members.php', {
    //                 method: 'POST',
    //                 body: formData
    //             })
    //             .then(response => response.text())
    //             .then(data => {
    //                 // Show success message
    //                 showToast('Member added successfully!', 'success');
                    
    //                 // Close modal
    //                 closeModal('addMemberModal');
                    
    //                 // Reset form
    //                 addForm.reset();
                    
    //                 // Reload page to show new member
    //                 setTimeout(() => {
    //                     window.location.reload();
    //                 }, 1000);
    //             })
    //             .catch(error => {
    //                 console.error('Error:', error);
    //                 showToast('Error adding member. Please try again.', 'error');
    //             })
    //             .finally(() => {
    //                 // Reset button state
    //                 submitBtn.disabled = false;
    //                 submitBtn.textContent = 'Add Member';
    //             });
    //         });
    //     }
    // });
    
    // Toast notification function
    function showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
    </script>
    <script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof openModal === 'function') {
        console.log('openModal function exists');
    } else {
        console.log('openModal function NOT found');
    }
});
</script>
    
    <!--<script>-->
    <!--// Simple test to check if JavaScript is working-->
    <!--document.addEventListener('DOMContentLoaded', function() {-->
    <!--    console.log('Page loaded successfully');-->
        
        <!--// Test if the form exists-->
    <!--    const addForm = document.getElementById('addMemberForm');-->
    <!--    if (addForm) {-->
    <!--        console.log('Add Member form found');-->
            
            <!--// Add a simple submit listener-->
    <!--        addForm.addEventListener('submit', function(e) {-->
    <!--            console.log('Form is being submitted!');-->
    <!--            console.log('Form data:', new FormData(this));-->
                <!--// Don't prevent default - let it submit normally-->
    <!--        });-->
            
            <!--// Also test the submit button click-->
    <!--        const submitBtn = addForm.querySelector('button[type="submit"]');-->
    <!--        if (submitBtn) {-->
    <!--            console.log('Submit button found');-->
    <!--            submitBtn.addEventListener('click', function(e) {-->
    <!--                console.log('Submit button clicked!');-->
                    
                    <!--// Check if form is valid-->
    <!--                console.log('Form valid:', addForm.checkValidity());-->
                    
                    <!--// Check for any validation errors-->
    <!--                const invalidElements = addForm.querySelectorAll(':invalid');-->
    <!--                console.log('Invalid elements:', invalidElements.length);-->
    <!--                invalidElements.forEach(function(element) {-->
    <!--                    console.log('Invalid element:', element.name, element.validationMessage);-->
    <!--                });-->
                    
                    <!--// Try to submit the form manually-->
    <!--                console.log('Attempting to submit form...');-->
    <!--                addForm.submit();-->
    <!--            });-->
    <!--        } else {-->
    <!--            console.log('Submit button NOT found');-->
    <!--        }-->
    <!--    } else {-->
    <!--        console.log('Add Member form NOT found');-->
    <!--    }-->
        
        <!--// Test if modal functions exist-->
    <!--    if (typeof openModal === 'function') {-->
    <!--        console.log('openModal function exists');-->
    <!--    } else {-->
    <!--        console.log('openModal function NOT found');-->
    <!--    }-->
    <!--});-->
    <!--</script>-->
    
    
    <!--<script>-->
    <!--// Simple test to check if JavaScript is working-->
    <!--document.addEventListener('DOMContentLoaded', function() {-->
    <!--    console.log('Page loaded successfully');-->
        
        <!--// Test if the form exists-->
    <!--    const addForm = document.getElementById('addMemberForm');-->
    <!--    if (addForm) {-->
    <!--        console.log('Add Member form found');-->
            
            <!--// Add a simple submit listener-->
    <!--        addForm.addEventListener('submit', function(e) {-->
    <!--            console.log('Form is being submitted!');-->
    <!--            console.log('Form data:', new FormData(this));-->
                
                <!--// Don't prevent default - let it submit normally-->
    <!--        });-->
            <!--// Also add click listener to submit button-->
    <!--        const submitBtn = addForm.querySelector('button[type="submit"]');-->
    <!--        if (submitBtn) {-->
    <!--            submitBtn.addEventListener('click', function(e) {-->
    <!--                console.log('Submit button clicked!');-->
    <!--                console.log('Form valid:', addForm.checkValidity());-->
                    
                    <!--// Check for validation errors-->
    <!--                const invalidElements = addForm.querySelectorAll(':invalid');-->
    <!--                if (invalidElements.length > 0) {-->
    <!--                    console.log('Validation errors found:', invalidElements.length);-->
    <!--                    invalidElements.forEach(function(element) {-->
    <!--                        console.log('Invalid field:', element.name, element.validationMessage);-->
    <!--                    });-->
    <!--                }-->
    <!--            });-->
    <!--        }-->
    <!--    } else {-->
    <!--        console.log('Add Member form NOT found');-->
    <!--    }-->
        
        <!--// Test if modal functions exist-->
    <!--    if (typeof openModal === 'function') {-->
    <!--        console.log('openModal function exists');-->
    <!--    } else {-->
    <!--        console.log('openModal function NOT found');-->
    <!--    }-->
    <!--});-->
    <!--</script>-->
</body>
</html> 