<?php
require_once '../config/database.php';

// Fetch pending members
$result = $conn->query("SELECT id, member_id, first_name, last_name, email, membership_type FROM members WHERE status = 'pending'");
$pendingMembers = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pending Members</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .pending-container {
            max-width: 900px;
            margin: 30px auto;
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        table { width: 100%; border-collapse: collapse; }
        table thead { background: #007bff; color: white; }
        table th, table td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        table tbody tr:hover { background: #f9f9f9; }
        .btn-approve { background: #28a745; color: white; padding: 6px 10px; border-radius: 4px; cursor: pointer; }
        .btn-reject { background: #dc3545; color: white; padding: 6px 10px; border-radius: 4px; cursor: pointer; }
        
        /* Animation styles */
        .fade-out { animation: fadeOut 0.5s forwards; }
        .highlight-green { background-color: #d4edda !important; transition: background-color 0.5s ease; }
        .highlight-red { background-color: #f8d7da !important; transition: background-color 0.5s ease; }
        @keyframes fadeOut {
            to { opacity: 0; height: 0; padding: 0; margin: 0; }
        }

        /* Toast Styles */
        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #333;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            opacity: 0;
            transform: translateY(-20px);
            animation: slideIn 0.4s forwards, fadeOutToast 0.5s 2.5s forwards;
            z-index: 9999;
        }
        @keyframes slideIn { to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeOutToast { to { opacity: 0; transform: translateY(-20px); } }
    </style>
</head>
<body>
<div class="pending-container">
    <h2>Pending Members</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Membership Type</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="membersTable">
            <?php foreach($pendingMembers as $member): ?>
                <tr id="memberRow_<?= $member['id'] ?>">
                    <td><?= htmlspecialchars($member['member_id']) ?></td>
                    <td><?= htmlspecialchars($member['first_name'].' '.$member['last_name']) ?></td>
                    <td><?= htmlspecialchars($member['email']) ?></td>
                    <td><?= htmlspecialchars($member['membership_type'] ?: '❌ Not set') ?></td>
                    <td>
                        <span class="btn-approve" onclick="updateStatus(<?= $member['id'] ?>, 'active')">Approve</span>
                        <span class="btn-reject" onclick="updateStatus(<?= $member['id'] ?>, 'inactive')">Reject</span>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
function updateStatus(memberId, status) {
    fetch('update_member_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + memberId + '&status=' + status
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            let row = document.getElementById('memberRow_' + memberId);

            // Add highlight color depending on action
            if (status === 'active') {
                row.classList.add('highlight-green');
                showToast('✅ Member Approved');
            } else {
                row.classList.add('highlight-red');
                showToast('❌ Member Rejected');
            }

            // Wait for highlight, then fade out
            setTimeout(() => {
                row.classList.add('fade-out');
                setTimeout(() => row.remove(), 500);
            }, 500);

        } else {
            showToast('⚠️ Error: ' + (data.message || 'Unknown error'));
        }
    })
    .catch(err => showToast('⚠️ Request failed: ' + err));
}

// Toast function
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}
</script>
</body>
</html>
