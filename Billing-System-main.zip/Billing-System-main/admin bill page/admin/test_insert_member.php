<?php
require_once '../config/database.php';

try {
    $pdo = getDBConnection();

    $stmt = $pdo->prepare("
        INSERT INTO members (member_id, first_name, last_name, email, country)
        VALUES (?, ?, ?, ?, ?)
    ");

    $memberId = 'MEM' . strtoupper(substr(md5(uniqid()), 0, 6));
    $stmt->execute([$memberId, 'TestFirst', 'TestLast', 'test' . rand(100, 999) . '@example.com', 'India']);

    echo "<h2 style='color:green'>✅ Test member inserted successfully!</h2>";
    echo "<p>Member ID: $memberId</p>";

} catch (PDOException $e) {
    echo "<h2 style='color:red'>❌ Error:</h2> " . $e->getMessage();
}
