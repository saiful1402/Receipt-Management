<?php
require_once '../config/database.php';
session_start();

// Security check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit();
}

// Fetch trashed members
$sql = "SELECT * FROM members_trash ORDER BY deleted_at DESC";
$result = $conn->query($sql);
$trashedMembers = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trashed Members - Billing Software</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .table-container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background-color: #343a40;
            color: #fff;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .actions a {
            text-decoration: none;
            margin-right: 8px;
            padding: 6px 10px;
            border-radius: 4px;
            color: #fff;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .restore-btn {
            background-color: #28a745;
        }
        .delete-btn {
            background-color: #dc3545;
        }
        .restore-btn:hover {
            background-color: #218838;
        }
        .delete-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

    <h2>Trashed Members</h2>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Member ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Membership</th>
                    <th>Status</th>
                    <th>Deleted At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($trashedMembers as $member): ?>
                <tr>
                    <td><?php echo htmlspecialchars($member['member_id']); ?></td>
                    <td><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></td>
                    <td><?php echo htmlspecialchars($member['email']); ?></td>
                    <td><?php echo htmlspecialchars($member['phone']); ?></td>
                    <td><?php echo htmlspecialchars($member['membership_type']); ?></td>
                    <td><?php echo htmlspecialchars($member['status']); ?></td>
                    <td><?php echo date('M j, Y H:i', strtotime($member['deleted_at'])); ?></td>
                    <td class="actions">
                        <a href="restore_member.php?id=<?php echo $member['id']; ?>" class="restore-btn">
                            <i class='bx bx-undo'></i> Restore
                        </a>
                        <a href="delete_permanent.php?id=<?php echo $member['id']; ?>" class="delete-btn">
                            <i class='bx bx-trash'></i> Delete
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</body>
</html>
