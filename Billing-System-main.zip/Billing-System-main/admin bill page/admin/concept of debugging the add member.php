<!--How the "Add Member" functionality works step by step:-->
<!--How the Add Member Process Works-->
<!--1. User Interface (Frontend)-->
<!-- <button onclick="openModal('addMemberModal')" class="btn btn-primary">Add New Member</button>-->

<!--User clicks "Add New Member" button-->
<!--This triggers openModal('addMemberModal') JavaScript function-->
<!--Modal popup appears with the form-->

<!--2. Form Structure-->
<!--<form method="POST" id="addMemberForm" action="members.php">-->
<!--    <input type="hidden" name="action" value="add">-->
    <!-- All the input fields -->
<!--    <button type="submit" class="btn btn-primary">Add Member</button>-->
<!--</form>-->

<!--Form uses POST method (sends data to server)-->
<!--Action="members.php" (sends to same page)-->
<!--Hidden input with name="action" value="add" tells PHP what to do-->

<!--3.When User Submits Form-->
<!--// From admin.js - form validation-->
<!--forms.forEach(form => {-->
<!--    form.addEventListener('submit', function (e) {-->
<!--        if (!form.id) return;-->
<!--        const isValid = validateForm(form.id);-->
<!--        if (!isValid) {-->
<!--            e.preventDefault(); // Stop submission if validation fails-->
<!--            alert('Please fill in all required fields.');-->
<!--        }-->
<!--    });-->
<!--});-->

<!--JavaScript validates all required fields-->
<!--If validation passes, form submits to members.php-->

<!--4. PHP Processing (Backend)-->
<!--// Check if it's a POST request-->
<!--if ($_SERVER['REQUEST_METHOD'] === 'POST') {-->
<!--    $action = $_POST['action'] ?? '';  // Gets "add" from hidden input-->
    
<!--    if ($action === 'add') {-->
<!--        // Process the add member logic-->
<!--    }-->
<!--}-->

<!--5. Data Processing Steps-->
<!--// Step 1: Generate unique member ID-->
<!--$memberId = generateMemberId();  // Creates like "MEMADF188"-->

<!--// Step 2: Get form data-->
<!--$amount = $_POST['amount'];  // Gets "7500" from form-->

<!--// Step 3: Prepare SQL statement-->
<!--$stmt = $conn->prepare("-->
<!--    INSERT INTO members -->
<!--    (member_id, first_name, last_name, email, phone, address, country, city, membership_type, amount, status, registration_date, created_at) -->
<!--    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())-->
<!--");-->

<!--// Step 4: Bind parameters (connect form data to SQL placeholders)-->
<!--$amount_float = (float)$amount;  // Convert to float-->
<!--$stmt->bind_param(-->
<!--    "sssssssssds",  // 11 parameters: s=string, d=decimal-->
<!--    $memberId,      // MEMADF188-->
<!--    $_POST['first_name'],    // "Debojit"-->
<!--    $_POST['last_name'],     // "Manna"-->
<!--    $_POST['email'],         // "debo20@gmail.com"-->
<!--    $_POST['phone'],         // "4444444444"-->
<!--    $_POST['address'],       // "Bandel, Hooghly, West Bengal"-->
<!--    $_POST['country'],       // "India"-->
<!--    $_POST['city'],          // "Kolkata"-->
<!--    $_POST['membership_type'], // "student member"-->
<!--    $amount_float,           // 7500.0-->
<!--    $_POST['status']         // "pending"-->
<!--);-->

<!--// Step 5: Execute the query-->
<!--if ($stmt->execute()) {-->
<!--    $message = "✅ Member added successfully!";-->
<!--} else {-->
<!--    $error = "❌ Insert failed: " . $stmt->error;-->
<!--}-->

<!--6. Database Insert-->
<!--The SQL becomes:-->
<!--INSERT INTO members -->
<!--(member_id, first_name, last_name, email, phone, address, country, city, membership_type, amount, status, registration_date, created_at) -->
<!--VALUES -->
<!--('MEMADF188', 'Debojit', 'Manna', 'debo20@gmail.com', '4444444444', 'Bandel, Hooghly, West Bengal', 'India', 'Kolkata', 'student member', 7500.0, 'pending', NOW(), NOW())-->

<!--7. Success Response-->
<!--// After successful insert, page reloads and shows:-->
<!--<?php if($message): ?>-->
<!--    <div class="alert alert-success">✅ Member added successfully!</div>-->
<!--<?php endif; ?>-->

<!--8. What Each Debug Line Shows-->
<!--error_log("POST received: " . print_r($_POST, true));-->
<!--// Shows: All form data being received-->

<!--error_log("Action: " . $action);-->
<!--// Shows: "add" - confirms we're in the right code block-->

<!--error_log("Processing ADD action");-->
<!--// Shows: Confirms we entered the add logic-->

<!--error_log("Generated Member ID: " . $memberId);-->
<!--// Shows: "MEMADF188" - the unique ID created-->

<!--error_log("Amount: " . $amount);-->
<!--// Shows: "7500" - the amount from form-->

<!--error_log("✅ Member inserted successfully!");-->
<!--// Shows: Confirms database insert worked-->

<!--The Flow Summary:-->
<!--User clicks → Modal opens-->
<!--User fills form → JavaScript validates-->
<!--User submits → POST data sent to PHP-->
<!--PHP processes → Generates ID, prepares SQL-->
<!--Database insert → Member saved-->
<!--Page reloads → Shows success message-->
<!--User sees → New member in table-->
<!--The key fix was: Converting (float)$amount to a variable $amount_float because bind_param() needs variables, not expressions!-->