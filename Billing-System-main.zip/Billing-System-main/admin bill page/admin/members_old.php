<?php
// ===============================
// OLD CODE SNIPPETS (BACKUP ONLY)
// ===============================

// --- DELETE using PDO ---
/*
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("DELETE FROM members WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $message = 'Member deleted successfully';
} catch (PDOException $e) {
    $error = 'Error deleting member: ' . $e->getMessage();
}
*/

// --- ADD/EDIT using PDO ---
/*
try {
    $pdo = getDBConnection();

    if ($action === 'add') {
        $memberId = generateMemberId();
        $stmt = $pdo->prepare("
            INSERT INTO members (member_id, first_name, last_name, email, phone, address, country, city, membership_type, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $memberId,
            $_POST['first_name'],
            $_POST['last_name'],
            $_POST['email'],
            $_POST['phone'],
            $_POST['address'],
            $_POST['country'],
            $_POST['city'],
            $_POST['membership_type'],
            $_POST['status']
        ]);
        $message = 'Member added successfully';
    } elseif ($action === 'edit') {
        $stmt = $pdo->prepare("
            UPDATE members SET 
                first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, 
                 city = ?, membership_type = ?, status = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $_POST['first_name'],
            $_POST['last_name'],
            $_POST['email'],
            $_POST['phone'],
            $_POST['address'],
            $_POST['city'],
            $_POST['membership_type'],
            $_POST['status'],
            $_POST['id']
        ]);
        $message = 'Member updated successfully';
    }
} catch (PDOException $e) {
    $error = 'Database Error: ' . $e->getMessage();
}
*/

// --- DEBUG Insert success/failure ---
/*
// echo "✅ Member inserted successfully! (Auto ID: " . $stmt->insert_id . ", Member ID: $memberId)";
// } else {
//     echo "❌ Insert failed: " . $stmt->error;
// }
*/

// --- OLD SELECT query (PDO) ---
/*
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM members $whereClause ORDER BY created_at DESC");
    $stmt->execute($params);
    $members = $stmt->fetchAll();

    $countStmt = $pdo->prepare("SELECT COUNT(*) as count FROM members $whereClause");
    $countStmt->execute($params);
    $filteredCount = $countStmt->fetch()['count'];
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $members = [];
    $filteredCount = 0;
}
*/

// --- OLD Status UI ---
/*
<span class="badge badge-<?php echo $member['status'] === 'active' ? 'active' : 'inactive'; ?>">
    <?php echo ucfirst(htmlspecialchars($member['status'])); ?>
</span>
<select onchange="updateStatus(<?php echo $member['id']; ?>, this.value)">
    <option value="pending"   <?php echo $member['status'] === 'pending'   ? 'selected' : ''; ?>>Pending</option>
    <option value="active"    <?php echo $member['status'] === 'active'    ? 'selected' : ''; ?>>Active</option>
    <option value="inactive"  <?php echo $member['status'] === 'inactive'  ? 'selected' : ''; ?>>Inactive</option>
    <option value="suspended" <?php echo $member['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
</select>
*/
?>
