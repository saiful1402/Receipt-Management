<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
// if (isset($_SESSION['success_message'])) {
//     echo "<div class='alert alert-success'>".$_SESSION['success_message']."</div>";
//     unset($_SESSION['success_message']); // clear after showing
// }
// if (isset($_SESSION['error_message'])) {
//     echo "<div class='alert alert-danger'>".$_SESSION['error_message']."</div>";
//     unset($_SESSION['error_message']);
// }
require_once '../config/database.php'; // adjust path

// Security check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit();
}

$message = '';
$error = '';

// Handle delete
// if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    
//     $stmt = $conn->prepare("DELETE FROM members WHERE id = ?");
//     $stmt->bind_param("i", $_GET['id']);
//     $stmt->execute();
//     $stmt->close();
// }

// Handle delete
// if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
//     $stmt = $conn->prepare("DELETE FROM members WHERE id = ?");
//     $stmt->bind_param("i", $_GET['id']);
//     if ($stmt->execute()) {
//         $_SESSION['success_message'] = "✅ Member deleted successfully!";
//     } else {
//         $_SESSION['error_message'] = "❌ Failed to delete member.";
//     }
//     $stmt->close();
//     header("Location: members.php");
//     exit();
// }

// Handle delete and move to trash
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $memberId = $_GET['id'];

    // 1️⃣ Get member data
    $stmt = $conn->prepare("SELECT * FROM members WHERE id = ?");
    $stmt->bind_param("i", $memberId);
    $stmt->execute();
    $result = $stmt->get_result();
    $member = $result->fetch_assoc();
    $stmt->close();

    if ($member) {
        // 2️⃣ Insert into trash table
        $stmt = $conn->prepare("INSERT INTO members_trash (member_id, first_name, last_name, email, phone, membership_type, status, registration_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "ssssssss",
            $member['member_id'],
            $member['first_name'],
            $member['last_name'],
            $member['email'],
            $member['phone'],
            $member['membership_type'],
            $member['status'],
            $member['registration_date']
        );
        $stmt->execute();
        $stmt->close();

        // 3️⃣ Delete from members table
        $stmt = $conn->prepare("DELETE FROM members WHERE id = ?");
        $stmt->bind_param("i", $memberId);
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "✅ Member deleted and moved to trash successfully!";
        } else {
            $_SESSION['error_message'] = "❌ Failed to delete member.";
        }
        $stmt->close();
    } else {
        $_SESSION['error_message'] = "❌ Member not found.";
    }

    // 4️⃣ Redirect back
    header("Location: members.php");
    exit();
}



// Filter parameters
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$status = $_GET['status'] ?? '';
$membershipType = $_GET['membership_type'] ?? '';
$search = $_GET['search'] ?? '';

// Build query
$whereConditions = [];
$params = [];

if ($startDate && $endDate) {
    $whereConditions[] = "DATE(registration_date) BETWEEN ? AND ?";
    $params[] = $startDate;
    $params[] = $endDate;
}

if ($status) {
    $whereConditions[] = "status = ?";
    $params[] = $status;
}

if ($membershipType) {
    $whereConditions[] = "membership_type = ?";
    $params[] = $membershipType;
}

if ($search) {
    $whereConditions[] = "(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR member_id LIKE ?)";
    $searchParam = "%$search%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';


$sql = "
    SELECT * FROM members
    $whereClause
    ORDER BY 
      CASE status
        WHEN 'pending' THEN 1
        WHEN 'active' THEN 2
        WHEN 'inactive' THEN 3
        WHEN 'suspended' THEN 4
        ELSE 5
      END,
      registration_date DESC
";
$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}
// echo "<pre>";
// echo $sql;
// print_r($params);
// echo "</pre>";

$stmt->execute();
$result = $stmt->get_result();
$members = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Count query
$sqlCount = "SELECT COUNT(*) as count FROM members $whereClause";
$countStmt = $conn->prepare($sqlCount);

if (!empty($params)) {
    $countStmt->bind_param($types, ...$params);
}

$countStmt->execute();
$countResult = $countStmt->get_result();
$filteredCount = $countResult->fetch_assoc()['count'];
$countStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members Management - Billing Software</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">-->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
    .toast {
  position: fixed;          /* Make it float */
  bottom: 20px;                /* Distance from top */
  right: 20px;              /* Distance from right */
  background: #28a745;      /* Default green success */
  color: white;
  padding: 12px 20px;
  border-radius: 6px;
  font-size: 14px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  z-index: 9999;            /* On top of everything */
  opacity: 0.95;
  transition: opacity 0.3s ease-in-out;
}
 Highlight colors 
.highlight-green { background-color: #d4edda !important; transition: background-color 0.5s ease; }
.highlight-red { background-color: #f8d7da !important; transition: background-color 0.5s ease; }
.highlight-orange { background-color: #fff3cd !important; transition: background-color 0.5s ease; }
.toast-error {
     background: #dc3545;  /* red */
}
.toast-warning {
    background: #ffc107;  /* yellow */
    color: #212529;
}
.toast-success {
     background: #28a745;  /* green */
}

/*.filter-bar {*/
/*    display: flex;*/
/*    justify-content: space-between;*/
/*    align-items: flex-end;*/
/*    flex-wrap: wrap;*/
/*    margin-bottom: 15px;*/
/*    gap: 20px;*/
/*}*/

/*.filter-left {*/
/*    display: flex;*/
/*    gap: 15px;*/
/*    flex-wrap: wrap;*/
/*}*/

/*.filter-group {*/
/*    display: flex;*/
/*    flex-direction: column;*/
/*}*/

/*.filter-right {*/
/*    min-width: 250px;*/
/*}*/

/*.filter-actions {*/
/*    margin-top: 10px;*/
/*}*/

/* New Filter Row Layout */
.filter-form-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    flex-wrap: wrap;
    gap: 20px;
}

.filter-left {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    align-items: flex-end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    min-width: 150px;
}

.filter-right {
    display: flex;
    flex-direction: column;
    min-width: 250px;
    /*height: 100vh;*/
}

.filter-actions {
    display: flex;
    gap: 10px;
    align-items: flex-end;
}
</style>
</head>
<body>
    <!-- Admin Header -->
    <header class="admin-header">
        <nav class="admin-nav">
            <h1>Billing Software Admin</h1>
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="members.php">Members</a>
                <a href="invoices.php">Invoices</a>
                <a href="reports.php">Reports</a>
                <!--<span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>-->
                <a href="../auth/logout.php" class="logout-btn">Logout</a>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h2>Members Management</h2>
            <div class="page-actions">
                <a href="add_member.php" class="btn btn-primary">Add New Member</a>
                <a href="trash.php" class="btn btn-warning">View Trash</a>
            </div>
        </div>

        <?php if($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Filter Section -->
        <!-- Filter Section -->
<div class="filter-section">
    <!--<form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="filterForm" class="filter-form-row">-->
    <form method="GET" action="" id="filterForm" class="filter-form-row">
        <!--<div class="filter-bar">-->
            <!-- Left side filters -->
            <div class="filter-left">
                <div class="filter-group">
                    <label for="start_date">Start Date</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
                </div>
                
                <div class="filter-group">
                    <label for="end_date">End Date</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
                </div>
                
                <div class="filter-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="">All Status</option>
                        <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        <option value="suspended" <?php echo $status === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="membership_type">Membership Type</label>
                    <select id="membership_type" name="membership_type">
                        <option value="">All Types</option>
                        <option value="life member" <?php echo $membershipType === 'life member' ? 'selected' : ''; ?>>Life Member</option>
                        <option value="executive member" <?php echo $membershipType === 'executive member' ? 'selected' : ''; ?>>Executive Member</option>
                        <option value="associate member" <?php echo $membershipType === 'associate member' ? 'selected' : ''; ?>>Associate Member</option>
                        <option value="student member" <?php echo $membershipType === 'student member' ? 'selected' : ''; ?>>Student Member</option>
                    </select>
                </div>
            </div>

            <!-- Right side search -->
            <div class="filter-right">
                <!--<div class="filter-group">-->
                    <label for="search">Search Users</label>
                    <input type="text" id="search" name="search" placeholder="Search by name, email, or ID" value="<?php echo htmlspecialchars($search); ?>">
                <!--</div>-->
            </div>
        <!--</div>-->

        <!-- Action buttons -->
        <div class="filter-actions">
            <button type="submit" class="btn btn-primary">Filter</button>
            <!--<a href="members.php" class="btn btn-secondary">Clear</a>-->
            <button type="button" class="btn btn-secondary" id="clearFilters">Clear</button>
        </div>
    </form>
</div>


        <!-- Results Summary -->
        <div class="results-summary">
            <p>Showing <?php echo $filteredCount; ?> member(s)</p>
        </div>

        <!-- Members Table -->
        <div class="table-container">
            <div class="table-header">
                <h3>Members List</h3>
                <div class="table-actions">
                    <button onclick="exportMembers()" class="btn btn-secondary btn-sm">Export</button>
                </div>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>Member ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Membership</th>
                        <th>Status</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($members as $member): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($member['member_id']); ?></td>
                        <td><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($member['email']); ?></td>
                        <td><?php echo htmlspecialchars($member['phone']); ?></td>
                        <td><?php echo ucfirst(htmlspecialchars($member['membership_type'])); ?></td>
                        <td>
                            <!--<span class="badge badge-<?php echo $member['status'] === 'active' ? 'active' : 'inactive'; ?>">-->
                            <!--    <?php echo ucfirst(htmlspecialchars($member['status'])); ?>-->
                            <!--</span>-->
                            <!--<select onchange="updateStatus(<?php echo $member['id']; ?>, this.value)">-->
                            <!--    <option value="pending"   <?php echo $member['status'] === 'pending'   ? 'selected' : ''; ?>>Pending</option>-->
                            <!--    <option value="active"    <?php echo $member['status'] === 'active'    ? 'selected' : ''; ?>>Active</option>-->
                            <!--    <option value="inactive"  <?php echo $member['status'] === 'inactive'  ? 'selected' : ''; ?>>Inactive</option>-->
                            <!--    <option value="suspended" <?php echo $member['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>-->
                            <!--</select>-->
                            <select class="status-select" data-id="<?php echo $member['id']; ?>">
                                <option value="pending"   <?php echo $member['status'] === 'pending'   ? 'selected' : ''; ?>>Pending</option>
                                <option value="active"    <?php echo $member['status'] === 'active'    ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive"  <?php echo $member['status'] === 'inactive'  ? 'selected' : ''; ?>>Inactive</option>
                                <option value="suspended" <?php echo $member['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                            </select>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($member['registration_date'])); ?></td>
                        <!--<td class="actions">-->
                        <!--    <a href="edit_member.php?id=<?php echo $member['id']; ?>" class="btn btn-warning btn-sm" title="Edit">-->
                        <!--        <i class="fas fa-edit"></i>-->
                        <!--    </a>-->
                        <!--    <button onclick="deleteMember(<?php echo $member['id']; ?>)" class="btn btn-danger btn-sm" title="Delete">-->
                        <!--         <i class="fas fa-trash"></i>-->
                        <!--    </button>-->
                        <!--</td>-->
                        <td class="actions">
                            <a href="edit_member.php?id=<?php echo $member['id']; ?>" class="btn btn-warning btn-sm" title="Edit">
                            <i class="bx bx-edit"></i>
                            </a>    
                            <button onclick="deleteMember(<?php echo $member['id']; ?>)" class="btn btn-danger btn-sm" title="Delete">
                            <i class="bx bx-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!--<script src="/public_html/admin bill page/assets/js/admin.js"></script>-->
    <script src="../assets/js/admin.js"></script>

    
         <script>
    // Toast notification function
    function showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
    </script>

<script>
document.getElementById("filterForm").addEventListener("submit", function(e) {
    console.log("Form submitted ✅");
    console.log("URL after submit will be:", this.action + "?" + new URLSearchParams(new FormData(this)).toString());
});
</script>

<?php if (isset($_SESSION['success_message'])): ?>
<script>
document.addEventListener("DOMContentLoaded", () => {
    showToast("<?php echo addslashes($_SESSION['success_message']); ?>", "success");
});
</script>
<?php unset($_SESSION['success_message']); endif; ?>

<?php if (isset($_SESSION['error_message'])): ?>
<script>
document.addEventListener("DOMContentLoaded", () => {
    showToast("<?php echo addslashes($_SESSION['error_message']); ?>", "error");
});
</script>
<?php unset($_SESSION['error_message']); endif; ?>

</body>
</html>