<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once '../config/database.php';

// Security check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit();
}
$message = '';
$error = '';

// ✅ Step A: Get Member by ID
if (!isset($_GET['id'])) {
    die("❌ No member ID provided.");
}
$id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT * FROM members where id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();
$stmt->close();

if (!$member) {
    die("❌ Member not found.");
}

// ✅ Step B: Update on POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $conn->prepare("
        UPDATE members SET 
            first_name=?, last_name=?, email=?, phone=?, address=?, 
            country=?, city=?, membership_type=?, amount=?, status=? 
        WHERE id=?
    ");
    $stmt->bind_param(
        "ssssssssdis",
        $_POST['first_name'],
        $_POST['last_name'],
        $_POST['email'],
        $_POST['phone'],
        $_POST['address'],
        $_POST['country'],
        $_POST['city'],
        $_POST['membership_type'],
        $_POST['amount'],
        $_POST['status'],
        $id
    );
//     if ($stmt->execute()) {
//         header("Location: members.php?success=1");
//         exit();
//     } else {
//         $error = "❌ Update failed: " . $stmt->error;
//     }
//     $stmt->close();

if ($stmt->execute()) {
    $_SESSION['success_message'] = "✅ Member updated successfully!";
    // header("Location: members.php");
    // exit();
} else {
    $_SESSION['error_message'] = "❌ Update failed: " . $stmt->error;
    // header("Location: members.php");
    // exit();
}
$stmt->close();
header("Location: members.php");
exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Member</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            margin-bottom: 25px;
            color: #222;
            text-align: center;
            font-weight: 600;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 6px;
            font-weight: 500;
            color: #444;
        }

        input,
        textarea,
        select {
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        input:focus,
        textarea:focus,
        select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
            outline: none;
        }

        textarea {
            resize: none;
            grid-column: span 2;
            /* Address takes full width */
        }

        .form-actions {
            display: flex;
            justify-content: center;
            margin-top: 25px;
            gap: 15px;
        }

        .btn {
            padding: 10px 20px;
            font-size: 15px;
            border-radius: 8px;
            cursor: pointer;
            border: none;
            transition: background 0.3s;
        }

        .btn-primary {
            background: #007bff;
            color: white;
        }

        .btn-primary:hover {
            background: #0056b3;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
            text-decoration: none;
        }

        .btn-secondary:hover {
            background: #565e64;
        }

        .alert {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            text-align: center;
        }

        .alert-success {
            background: #28a745;
            color: white;
            font-weight: 600;
        }

        .alert-danger {
            background: #dc3545;
            color: white;
            font-weight: 600;
        }
    </style>
</head>

<body>

    <div class="container">
        <h2>Edit Member</h2>
        <?php if ($error) echo "<div class='alert alert-danger'>$error</div>"; ?>

        <form method="POST" class="form-grid">
            <div class="form-group">
               <label>First Name</label>
                <input type="text" name="first_name" value="<?php echo htmlspecialchars($member['first_name']); ?>" required> 
            </div>
            
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" name="last_name" value="<?php echo htmlspecialchars($member['last_name']); ?>" required>
            </div>
            
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($member['email']); ?>" required>
            </div>
            
            <div class="form-group">
                <label>Phone</label>
                <input type="number" name="phone" value="<?php echo htmlspecialchars($member['phone']); ?>" required>
            </div>
            
            <div class="form-group" style="grid-column: span 2;">
                <label>Address</label>
                <textarea name="address" rows="3"><?php echo htmlspecialchars($member['address']); ?></textarea>
            </div>
            
            <div class="form-group">
                <label>Country</label>
                <input type="text" name="country" value="<?php echo htmlspecialchars($member['country']); ?>" required>
            </div>
            
            <div class="form-group">
                <label>City</label>
                <input type="text" name="city" value="<?php echo htmlspecialchars($member['city']); ?>" required>
            </div>
            
            <div class="form-group">
                <label>Membership Type</label>
                <select name="membership_type">
                    <option value="life member" <?php if ($member['membership_type'] == 'life member') echo 'selected'; ?>>Life Member</option>
                    <option value="executive member" <?php if ($member['membership_type'] == 'executive member') echo 'selected'; ?>>Executive Member</option>
                    <option value="associate member" <?php if ($member['membership_type'] == 'associate member') echo 'selected'; ?>>Associate Member</option>
                    <option value="student member" <?php if ($member['membership_type'] == 'student member') echo 'selected'; ?>>Student Member</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Amount</label>
                <input type="number" step="0.01" name="amount" value="<?php echo htmlspecialchars($member['amount']); ?>" required>
            </div>
            
            <div class="form-group">
                <label>Status</label>
                <select name="status" required>
                    <option value="pending" <?php if ($member['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                    <option value="active" <?php if ($member['status'] == 'active') echo 'selected'; ?>>Active</option>
                    <option value="inactive" <?php if ($member['status'] == 'inactive') echo 'selected'; ?>>Inactive</option>
                    <option value="suspended" <?php if ($member['status'] == 'suspended') echo 'selected'; ?>>Suspended</option>
                </select>
            </div>
                
            <div class="form-actions" style = "grid-column: span 2;">
                <button type="submit" class="btn btn-primary">Update Member</button>
                <a href="members.php" class="btn btn-secondary">Cancel</a>
            </div>    
            
        </form>
    </div>
</body>

</html>