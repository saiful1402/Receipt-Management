<?php
// Create this as a separate file: test_insert.php
// Place it in the same directory as members.php

require_once '../config/database.php';

try {
    $pdo = getDBConnection();
    echo "✅ Database connection successful<br>";
    
    // Test generateMemberId function
    $memberId = generateMemberId();
    echo "✅ Generated Member ID: " . $memberId . "<br>";
    
    // Test insert
    $stmt = $pdo->prepare("
        INSERT INTO members (member_id, first_name, last_name, email, phone, address, country, city, membership_type, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $result = $stmt->execute([
        $memberId,
        'Final',
        'hhhh',
        'test' . time() . '@example.com', // unique email
        '123-456-7890',
        '123 Test St',
        'bn',
        'Test City',
        'student member',
        'active'
    ]);
    
    if($result) {
        echo "✅ SUCCESS: Test member inserted successfully!<br>";
        echo "Member ID: " . $memberId . "<br>";
    } else {
        echo "❌ FAILED: Insert returned false<br>";
    }
    
} catch(PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "<br>";
    echo "Error Code: " . $e->getCode() . "<br>";
} catch(Exception $e) {
    echo "❌ General Error: " . $e->getMessage() . "<br>";
}
?>