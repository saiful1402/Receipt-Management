<!--Debug form submission-->
    <!--document.addEventListener('DOMContentLoaded', function() {-->
    <!--    const addForm = document.getElementById('addMemberForm');-->
    <!--    if (addForm) {-->
    <!--        addForm.addEventListener('submit', function(e) {-->
    <!--            console.log('Form submitted!');-->
    <!--            console.log('Form data:', new FormData(this));-->
    <!--        });-->
    <!--    }-->
    <!--});-->
    
    <!-- Test submit function-->
    <!--function testSubmit() {-->
    <!--    console.log('Test submit clicked');-->
    <!--    const form = document.getElementById('addMemberForm');-->
    <!--    if (form) {-->
    <!--        console.log('Form found, submitting...');-->
    <!--        form.submit();-->
    <!--    } else {-->
    <!--        console.log('Form not found!');-->
    <!--    }-->
    <!--}-->
    <!--</script>-->
    <!--<script>-->
     <!--Simple test to check if JavaScript is working-->
    <!--document.addEventListener('DOMContentLoaded', function() {-->
    <!--    console.log('Page loaded successfully');-->
        
         <!--Test if the form exists-->
    <!--    const addForm = document.getElementById('addMemberForm');-->
    <!--    if (addForm) {-->
    <!--        console.log('Add Member form found');-->
            
             <!--Add a simple submit listener-->
    <!--        addForm.addEventListener('submit', function(e) {-->
    <!--            console.log('Form is being submitted!');-->
                 <!--Don't prevent default - let it submit normally-->
    <!--        });-->
             <!--Also test the submit button click-->
    <!--        const submitBtn = addForm.querySelector('button[type="submit"]');-->
    <!--        if (submitBtn) {-->
    <!--            console.log('Submit button found');-->
    <!--            submitBtn.addEventListener('click', function(e) {-->
    <!--                console.log('Submit button clicked!');-->
                    
                     <!--Check if form is valid-->
    <!--                console.log('Form valid:', addForm.checkValidity());-->
                    
                     <!--Check for any validation errors-->
    <!--                const invalidElements = addForm.querySelectorAll(':invalid');-->
    <!--                console.log('Invalid elements:', invalidElements.length);-->
    <!--                invalidElements.forEach(function(element) {-->
    <!--                    console.log('Invalid element:', element.name, element.validationMessage);-->
    <!--                });-->
                    
                     <!--Try to submit the form manually-->
    <!--                console.log('Attempting to submit form...');-->
    <!--                addForm.submit();-->
    <!--            });-->
    <!--        } else {-->
    <!--            console.log('Submit button NOT found');-->
    <!--        }-->
    <!--    } else {-->
    <!--        console.log('Add Member form NOT found');-->
    <!--    }-->
        
         <!--Test if modal functions exist-->
    <!--    if (typeof openModal === 'function') {-->
    <!--        console.log('openModal function exists');-->
    <!--    } else {-->
    <!--        console.log('openModal function NOT found');-->
    <!--    }-->
    <!--});-->
    <!--</script>-->
    
    
    // i have also tried this but didn't work at all
    
    <!--<script>-->
    <!--// Simple test to check if JavaScript is working-->
    <!--document.addEventListener('DOMContentLoaded', function() {-->
    <!--    console.log('Page loaded successfully');-->
        
        <!--// Test if the form exists-->
    <!--    const addForm = document.getElementById('addMemberForm');-->
    <!--    if (addForm) {-->
    <!--        console.log('Add Member form found');-->
            
            <!--// Add a simple submit listener-->
    <!--        addForm.addEventListener('submit', function(e) {-->
    <!--            console.log('Form is being submitted!');-->
    <!--            console.log('Form data:', new FormData(this));-->
                
                <!--// Don't prevent default - let it submit normally-->
    <!--        });-->
            <!--// Also add click listener to submit button-->
    <!--        const submitBtn = addForm.querySelector('button[type="submit"]');-->
    <!--        if (submitBtn) {-->
    <!--            submitBtn.addEventListener('click', function(e) {-->
    <!--                console.log('Submit button clicked!');-->
    <!--                console.log('Form valid:', addForm.checkValidity());-->
                    
                    <!--// Check for validation errors-->
    <!--                const invalidElements = addForm.querySelectorAll(':invalid');-->
    <!--                if (invalidElements.length > 0) {-->
    <!--                    console.log('Validation errors found:', invalidElements.length);-->
    <!--                    invalidElements.forEach(function(element) {-->
    <!--                        console.log('Invalid field:', element.name, element.validationMessage);-->
    <!--                    });-->
    <!--                }-->
    <!--            });-->
    <!--        }-->
    <!--    } else {-->
    <!--        console.log('Add Member form NOT found');-->
    <!--    }-->
        
        <!--// Test if modal functions exist-->
    <!--    if (typeof openModal === 'function') {-->
    <!--        console.log('openModal function exists');-->
    <!--    } else {-->
    <!--        console.log('openModal function NOT found');-->
    <!--    }-->
    <!--});-->
    <!--</script>-->