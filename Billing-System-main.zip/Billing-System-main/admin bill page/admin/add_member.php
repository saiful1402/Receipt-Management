<?php
session_start();
require_once '../config/database.php';

// Security check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: ../auth/login.php');
    exit();
}

$message = '';
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $memberID = generateMemberId();
    $amount = (float)($_POST['amount'] ?? 0);
    
    $stmt = $conn->prepare("
    INSERT INTO members
    (member_id, first_name, last_name, email, phone, address, country, city, membership_type, amount, status, registration_date, created_at)
    VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ");
    if($stmt){
        $stmt->bind_param(
            "sssssssssds",
            $memberID,
            $_POST['first_name'],
            $_POST['last_name'],
            $_POST['email'],
            $_POST['phone'],
            $_POST['address'],
            $_POST['country'],
            $_POST['city'],
            $_POST['membership_type'],
            $amount,
            $_POST['status']
            );
            if ($stmt->execute()){
                // $message = "✅ Member added successfully!";
                $_SESSION['success_message'] = "✅ Member added successfully!";
                header("Location: members.php");
                exit();
            } else {
                // $error = "❌ Insert failed: " . $stmt->error;
                $_SESSION['error_message'] =  "❌ Insert failed: " . $stmt->error;
                header("Location: members.php");
                exit();
            }
            $stmt->close();
    } else {
        $error = "❌ Prepare failed: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
    <title>Add Member</title>
    <link rel="stylesheet href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0,0,0,0.1);
        }

        h2 {
            margin-bottom: 25px;
            color: #222;
            text-align: center;
            font-weight: 600;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 6px;
            font-weight: 500;
            color: #444;
        }

        input, textarea, select {
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus, select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0,123,255,0.3);
            outline: none;
        }

        textarea {
            resize: none;
        }

        .form-actions {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            font-size: 15px;
            border-radius: 8px;
            cursor: pointer;
            border: none;
            transition: background 0.3s;
        }

        .btn-primary {
            background: #007bff;
            color: white;
        }

        .btn-primary:hover {
            background: #0056b3;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
            text-decoration: none;
        }

        .btn-secondary:hover {
            background: #565e64;
        }

        .alert {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            text-align: center;
        }

        .alert-success {
            background: #28a745;
            color: #fff;
            font-weight: 600;
            border-left: 6px solid #1e7e34; /* Darker green stripe */
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
        }
    </style>
    </head>
    <body>
    <div class="container">
        <h2>Add New Member</h2>
        <?php if ($message) echo "<div class='alert alert-success'>$message</div>"; ?>
        <?php if ($error) echo "<div class='alert alert-danger'>$error</div>"; ?>

        <form method="POST">
            <div class="form-grid">
                <div class="form-group">
                    <label>First Name</label>
                    <input type="text" name="first_name" required>
                </div>
            
                <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" name="last_name" required>
                </div>
            
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" required>
                </div>
        
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone">
                </div>

                <div class="form-group" style="grid-column: span 2;">
                    <label>Address</label>
                    <textarea name="address" rows="3"></textarea>
                </div>
        
                <div class="form-group">
                    <label>Country</label>
                    <input type="text" name="country">
                </div>
        
                <div class="form-group">
                    <label>City</label>
                    <input type="text" name="city">
                </div>
        
                <div class="form-group">
                    <label>Membership Type</label>
                    <select name="membership_type" required>
                        <option value="">-- Select --</option>
                        <option value="life member">Life Member</option>
                        <option value="executive member">Executive Member</option>
                        <option value="associate member">Associate Member</option>
                        <option value="student member">Student Member</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Amount</label>
                    <input type="number" step="0.01" name="amount">
                </div>
            
                <div>
                    <label>Status</label>
                    <select name="status" required>
                        <option value="pending">Pending</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="suspended">Suspended</option>
                    </select>  
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Add Member</button>
                <a href="members.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
    </body>
</html>